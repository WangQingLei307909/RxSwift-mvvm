//
//  AnchorModel.swift
//  GYJTV
//
//  Created by 田全军 on 2017/7/20.
//  Copyright © 2017年 Quanjun. All rights reserved.
//

import UIKit
import ObjectMapper
import RxDataSources

struct AnchorModel: Mappable {
    var category = ""
    var group_url = ""
    var title = ""
    var thumb_url = ""
    var image_url = ""
    var objectId = ""
    
    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        
        category  <- map["category"]
        group_url <- map["group_url"]
        title     <- map["title"]
        thumb_url <- map["thumb_url"]
        image_url <- map["image_url"]
        objectId  <- map["objectId"]
    }
}


//MARK: SectionModel
struct AnchorSection {
    // items就是rows
    var items: [Item]
    
    // 你也可以这里加你需要的东西，比如 headerView 的 title
}

extension AnchorSection: SectionModelType {
    // 重定义 Item 的类型为
    typealias Item = AnchorModel
    init(original: AnchorSection, items: [AnchorSection.Item]) {
        self = original
        self.items = items
    }
}
