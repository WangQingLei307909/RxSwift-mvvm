//
//  AnchorModel.swift
//  GYJTV
//
//  Created by 田全军 on 2017/7/20.
//  Copyright © 2017年 Quanjun. All rights reserved.
//

import UIKit
import ObjectMapper
import RxDataSources

struct AnchorModel: Mappable {
    
    var category = ""
    var group_url = ""
    var title = ""
    var thumb_url = ""
    var image_url = ""
    var objectId = ""

    /*
     这里没有用到josn转model的复杂使用方式，我这里模拟一下嵌套，如果嵌套里面继续嵌套，下面方式以此类推
     定义一个数组属性 array
     定义一个字典属性 dic
     
     1、model里面有一个属性是数组
     2、model里面有一个属性是字典
     */
    
    /*
     //模拟嵌套属性Array
     var array: [NestedArrayModel] = [NestedArrayModel]()
     //模拟嵌套属性Dic
     var dic: [NestedDicModel] = [NestedDicModel]()
     */

    init?(map: Map) {
        
    }
    
    mutating func mapping(map: Map) {
        
        category  <- map["category"]
        group_url <- map["group_url"]
        title     <- map["title"]
        thumb_url <- map["thumb_url"]
        image_url <- map["image_url"]
        objectId  <- map["objectId"]
        /*
         array     <- map["array"]
         dic       <- map["dic"]
         */
    }

}

//MARK: 自定义 SectionModel
struct AnchorSection {
    // items就是rows
    var items: [Item]
    
    
    //设置分组，title为组头名称如果不b分组下面代码注释掉
    /*
     var title: String
     // 你也可以这里加你需要的东西，比如 headerView 的 title
     init(title:String , items:[Item]) {
         self.title = title
         self.items = items
     }
     */

}

extension AnchorSection: SectionModelType {
    // 重定义 Item 的类型为
    typealias Item = AnchorModel
    init(original: AnchorSection, items: [AnchorSection.Item]) {
        self = original
        self.items = items
    }
}

/*
 struct NestedArrayModel: Mappable {
     
     var nested_array_id = ""
     var nested_array_url = ""
     var nested_array_title = ""
     
     init?(map: Map) {
         
     }
     
     mutating func mapping(map: Map) {
         nested_array_id    <- map["nested_array_id"]
         nested_array_url   <- map["nested_array_url"]
         nested_array_title <- map["nested_array_title"]
     }

 }

 struct NestedDicModel: Mappable {
     
     var nested_dic_id = ""
     var nested_dic_url = ""

     init?(map: Map) {
         
     }
     
     mutating func mapping(map: Map) {
         nested_dic_id  <- map["nested_dic_id"]
         nested_dic_url <- map["nested_dic_url"]
     }

 }
 */

// MARK:- 这里列举一个JSON转Model嵌套方式的例子，如果涉及到嵌套可参考下面方式

/*
 class itemListModel: Mappable {
  
     ///项目ID
     var itemId : String = ""
  
     ///项目名称
     var itemName : String = ""
  
     //项目组ID
     var groupId : String = ""
  
     //项目编号
     var itemCode : String = ""
  
     //价格
     var price : String = ""
  
     //购买数量
     var count : String = ""
  
     func mapping(map: Map) {
         itemId <- map["itemId"]
         itemName <- map["itemName"]
         groupId <- map["groupId"]
         itemCode <- map["itemCode"]
         price <- map["price"]
         count <- map["count"]
     }
  
     required init?(map: Map) {
         mapping(map: map)
     }
 }
  
 ///bookingInfo
 class BookingInfoModel: Mappable {
  
     ///星级 0否 1是
     var starYn : String = ""
  
     ///星座
     var constellation : String = ""
  
     ///预约的项目
     var itemList : [itemListModel] =  [itemListModel]()
  
     ///预约日期 ===
     var bookingDate : String = ""
  
     ///预约ID ==
     var bookingId : String = ""
  
     ///手机号码 ===
     var cellPhone : String = ""
  
     ///顾客编号 ===
     var customerCode : String = ""
  
     ///顾客性别 ===
     var customerGener : String = ""
  
     ///顾客ID ===
     var customerId : String? = ""
  
     ///顾客姓名 ===
     var customerName : String = ""
  
     ///员工编号 ===
     var employeeCode : String = ""
  
     ///员工性别 ===
     var employeeGener : String = ""
  
     ///员工ID =====
     var employeeId : String = ""
  
     ///员工姓名 ====
     var employeeName : String = ""
  
     ///项目编号
     var itemCode : String = ""
  
     ///员工职位名称 ===
     var positionName : String = ""
  
     ///员工职位ID （1.1.1版本新增字段）
     var positionId : String = ""
  
     ///预约时间 ==
     var startTime : String = ""
  
     init() { }
  
     func mapping(map: Map) {
  
         starYn <- map["starYn"]
         constellation <- map["constellation"]
  
         bookingDate <- map["bookingDate"]
         bookingId <- map["bookingId"]
         cellPhone <- map["cellPhone"]
         customerCode <- map["customerCode"]
         customerGener <- map["customerGener"]
         customerId <- map["customerId"]
         customerName <- map["customerName"]
         employeeCode <- map["employeeCode"]
         employeeGener <- map["employeeGener"]
         employeeId <- map["employeeId"]
         employeeName <- map["employeeName"]
         itemCode <- map["itemCode"]
         itemList <- map["itemList"]
         positionName <- map["positionName"]
         startTime <- map["startTime"]
         positionId <- map["positionId"]
     }
  
     required init?(map: Map) {
         mapping(map: map)
     }
 }
  
 ///bookingInfoList
 class BookingInfoListModel: Mappable {
  
     ///对应的时间分组
     var bookingInfo : [BookingInfoModel] = [BookingInfoModel]()
  
     /// 时间
     var time : String = ""
  
     func mapping(map: Map) {
         bookingInfo <- map["bookingInfo"]
         time <- map["time"]
     }
  
     required init?(map: Map) {
         mapping(map: map)
     }
 }
  
 ///val
 class ValForBespeakModel: Mappable {
  
     ///某个时间点的预约信息
     var bookingInfoList : [BookingInfoListModel] = [BookingInfoListModel]()
  
     ///预约总人数
     var number : String = ""
     init() { }
     func mapping(map: Map) {
         bookingInfoList <- map["bookingInfoList"]
         number <- map["number"]
     }
  
     required init?(map: Map) {
         mapping(map: map)
     }
 }
  
 /// obj
 class QueryBespeakModel: Mappable {
  
     var msg : String  = ""
     var ret : String  = ""
     var val : [ValForBespeakModel] = [ValForBespeakModel]()
  
     func mapping(map: Map) {
         msg <- map["msg"]
         ret <- map["ret"]
         val <- map["val"]
     }
  
     required init?(map: Map) {
         mapping(map: map)
     }
 }
 
 */
