//
//  Config.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import FCUUID
let kScreenWidth  = UIScreen.main.bounds.size.width
let kScreenHeight = UIScreen.main.bounds.size.height


//MARK:-此处是跑真虚拟机
let kScreenBounds = UIScreen.main.bounds
let kSafeAreaTopHeight      = SwiftTool.isItSpecialCurvedScreen() ? 88 : 88
let kSafeAreaStatusHeight   = SwiftTool.isItSpecialCurvedScreen() ? 44 : 20
let kSafeAreaMoreThanHeight = SwiftTool.isItSpecialCurvedScreen() ? 20 : 0
let kSafeAreaBottomHeight   = SwiftTool.isItSpecialCurvedScreen() ? 34 : 0

// MARK: - 获取系统版本号和历史版本号
//获取当前版本号
let currentVersion = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
//获取历史版本号
let sandboxVersion = UserDefaults.standard.object(forKey: "CFBundleShortVersionString") as? String ?? ""

// MARK: - 获取APP信息、名称、版本号以及build版本号
//获取app信息
let infoDictionary : Dictionary = Bundle.main.infoDictionary!
//程序名称
let appDisplayName : String = infoDictionary["CFBundleDisplayName"] as! String
//版本号
let majorVersion : String = infoDictionary ["CFBundleShortVersionString"] as! String
//build号
let minorVersion : String = infoDictionary ["CFBundleVersion"] as! String

// MARK: - 获取设备信息
//ios版本
let iosVersion : NSString = UIDevice.current.systemVersion as NSString
//设备udid
let identifierNumber  = UIDevice.current.identifierForVendor
//设备名称
let deviceName : String = UIDevice.current.name
//系统名称
let systemName : String = UIDevice.current.systemName
//设备型号
let model = UIDevice.current.model
//设备区域化型号如A1533
let localizedModel = UIDevice.current.localizedModel
// 设备UUID
let deviceUUID = FCUUID.uuidForDevice()

