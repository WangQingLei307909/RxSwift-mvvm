//
//  AppDelegate.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

let appKey = ""
let isProduction = true
let channel = "Publish channel";

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        DarkManager.setWindowDarkModeSwicth()
        self.window?.rootViewController = UINavigationController(rootViewController: RxSwiftTabBarC())
        return true
    }

}


// MARK:- 类扩展 - 激光推送相关
extension AppDelegate:JPUSHRegisterDelegate {
    func registerJPush(launchOptions: [UIApplication.LaunchOptionsKey: Any]?){
        //注册极光推送
        let entity = JPUSHRegisterEntity()
        entity.types = 1 << 0 | 1 << 1 | 1 << 2
        JPUSHService.register(forRemoteNotificationConfig: entity, delegate: self)
        //需要IDFA 功能，定向投放广告功能
        //let advertisingId = ASIdentifierManager.shared().advertisingIdentifier.uuidString
        //通知类型（这里将声音、消息、提醒角标都给加上）
        let userSettings = UIUserNotificationSettings(types: [.alert, .badge, .sound], categories: nil)
        if ( (UIDevice.current.systemVersion as NSString).floatValue >= 8.0 ) {
            //可以添加自定义categories
            JPUSHService.register(forRemoteNotificationTypes: userSettings.types.rawValue,categories: nil)
        } else {
            //categories 必须为nil
            JPUSHService.register(forRemoteNotificationTypes: userSettings.types.rawValue, categories: nil)
        }
        JPUSHService.setup(withOption: launchOptions, appKey: appKey, channel: channel, apsForProduction: isProduction, advertisingIdentifier: nil)
    }
    
    //极光推送需要实现的代理方法
       // iOS 10.x 需要
    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, willPresent notification: UNNotification!, withCompletionHandler completionHandler: ((Int) -> Void)!) {
       
       let userInfo = notification.request.content.userInfo
       if notification.request.trigger is UNPushNotificationTrigger {
           JPUSHService.handleRemoteNotification(userInfo)
       }
       // 需要执行这个方法，选择是否提醒用户，有Badge、Sound、Alert三种类型可以选择设置
       completionHandler(Int(UNNotificationPresentationOptions.alert.rawValue))
    }

    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, didReceive response: UNNotificationResponse!, withCompletionHandler completionHandler: (() -> Void)!) {
       let userInfo = response.notification.request.content.userInfo
       if response.notification.request.trigger is UNPushNotificationTrigger {
           JPUSHService.handleRemoteNotification(userInfo)
       }
       // 系统要求执行这个方法
       completionHandler()
    }

    //系统获取Token
    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
       UserDefaults.standard.set(deviceToken, forKey: "deviceToken")
       JPUSHService.registerDeviceToken(deviceToken)
    }

    //点推送进来执行这个方法
    func application(_ application: UIApplication, didReceiveRemoteNotification userInfo: [AnyHashable : Any], fetchCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
       JPUSHService.handleRemoteNotification(userInfo)
       completionHandler(UIBackgroundFetchResult.newData)
    }

    //获取token 失败
    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) { //可选
       print("did Fail To Register For Remote Notifications With Error: \(error)")
    }

    func jpushNotificationCenter(_ center: UNUserNotificationCenter!, openSettingsFor notification: UNNotification?) {
       
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
       //在应用进入后台时清除推送消息角标
       application.applicationIconBadgeNumber = 0
       JPUSHService.setBadge(0)
    }
    
}
