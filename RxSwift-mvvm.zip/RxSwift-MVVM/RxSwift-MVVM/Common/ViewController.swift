//
//  ViewController.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import WisdomHUD
class ViewController: UIViewController {
    
    /// 在iOS13以后默认present跳页默认不再是全屏展示，所以父类这里重写init方法，这样就可以只要集成当前类，就可以不用单独设置了
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.modalPresentationStyle = .fullScreen
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
        listeningToTheKeyboard()
    }
    
    /// 监听键盘响应事件
    func listeningToTheKeyboard() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    // 键盘弹出
    @objc func keyboardWillShow(note:NSNotification){

    }
    
    //键盘隐藏
    @objc func keyboardWillHide(note:NSNotification){

    }

    //简书键盘第一响应
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //离开此页面时，去掉加载弹框
    override func viewWillDisappear(_ animated: Bool) {
        WisdomHUD.dismiss()
    }
    
}


extension ViewController {
    func darkMode()  {
        if #available(iOS 11.0, *) {
            self.view.backgroundColor = UIColor(named: "bgcolor")
        } else {
            self.view.backgroundColor = SwiftColor.bgViewColor
        }
    }
}
