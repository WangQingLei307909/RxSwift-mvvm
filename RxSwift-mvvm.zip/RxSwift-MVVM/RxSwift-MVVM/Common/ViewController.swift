//
//  ViewController.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
    }

}


extension ViewController {
    func darkMode()  {
        if #available(iOS 11.0, *) {
            self.view.backgroundColor = UIColor(named: "bgcolor")
        } else {
            self.view.backgroundColor = SwiftColor.bgViewColor
        }
    }
}
