//
//  RxSwiftRootVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class RxSwiftRootVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    lazy var dataSource: Array<String> = {
        let array = ["二维码识别、扫描、生成",
                     "RxSwift - TableView",
                     "RxSwift - UICollectionView",
                     "RxSwift - 其他控件的简单使用",
                     "RxSwift - 登录",
                     "RxSwift - Subjects",
                     "RxSwift - Variable",
                     "RxSwift - doOn",
                     "RxSwift - Dispose",
                     "RxSwift - bindto",
                     "RxSwift - 变化操作符",
                     "RxSwift - 条件和布尔操作符",
                     "RxSwift - 结合操作符",
                     "RxSwift - 算数聚合操作符",
                     "Rxswift - 连接操作符",
                     "RxSwift - 其他操作符",
                     "RxSwift - 错误处理",
                     "RxSwift - 调试操作",
                     "RxSwift - 特征序列 - 1",
                     "RxSwift - 特征序列 - 2",
                     "RxSwift - Driver","RxSwift - Schedulers"]
        return array
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "RxSwift + Moya + MVVM + 应用"
    }
    
}

extension RxSwiftRootVC: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if  cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        cell?.selectionStyle = .none
        cell?.textLabel?.textColor = indexPath.row == 1 || indexPath.row == 2 ? .red : .black
        cell?.detailTextLabel?.text  = indexPath.row == 1 || indexPath.row == 2 ? "MVVM + Moya + RxSwift" : ""
        cell?.textLabel?.text = dataSource[indexPath.row]
        cell?.accessoryType = .disclosureIndicator
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            let vc = MyVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 1:
            let vc = TableViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 2:
            let vc = CollectionViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
            let vc = OrdinaryTableViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
            let vc = RxSwiftLoginVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 5:
            let vc = RxSwiftSubjectsVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 6:
            let vc = RxSwiftVariableVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 7:
            let vc = RxSwiftdoOnVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 8:
            let vc = RxSwiftDisposeVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 9:
            let vc = RxSwiftBindtoVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 10:
            let vc = RxSwiftTransformingVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 11:
            let vc = RxSwiftFilterBoolVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 12:
            let vc = RxSwiftCombiningVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 13:
            let vc = RxSwiftMathematicalAggregateVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 14:
            let vc = RxSwiftConnectableVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 15:
            let vc = RxSwiftObservableUtilityVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 16:
            let vc = RxSwiftErrorVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 17:
            let vc = RxSwiftDebugVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 18:
            let vc = RxSwiftTraits1VC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 19:
            let vc = RxSwiftControlPropertyVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 20:
            let vc = RxSwiftDriverVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 21:
            let vc = RxSwiftSchedulersVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        default:
            break
        }
    }
    
}
