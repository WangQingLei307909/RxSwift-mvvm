//
//  RxSwiftRootVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftRootVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    lazy var dataSource: Array<String> = {
        let array = ["登录",
                     "TableView",
                     "UICollectionView",
                     "其他控件的简单使用",
                     "二维码"]
        return array
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

extension RxSwiftRootVC: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if  cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        cell?.selectionStyle = .none
        cell?.textLabel?.text = dataSource[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            self.navigationController?.pushViewController(RxSwiftLoginVC(), animated: true)
            break
        case 1:
            self.navigationController?.pushViewController(TableViewVC(), animated: true)
            break
        case 2:
            self.navigationController?.pushViewController(CollectionViewVC(), animated: true)
            break
        case 3:
            self.navigationController?.pushViewController(OrdinaryTableViewVC(), animated: true)
            break
        case 4:
            self.navigationController?.pushViewController(MyVC(), animated: true)
            break
        default:
            break
        }

    }
    
}
