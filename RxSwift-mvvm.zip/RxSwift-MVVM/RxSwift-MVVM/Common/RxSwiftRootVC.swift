//
//  RxSwiftRootVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftRootVC: ViewController {

    @IBOutlet weak var otherButton: UIButton!
    @IBOutlet weak var collectionViewButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var tableViewButton: UIButton!
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "RxSwift"
        loginButton.rx.tap.subscribe(onNext: {
            self.navigationController?.pushViewController(RxSwiftLoginVC(), animated: true)
            }).disposed(by: disposeBag)
        
        tableViewButton.rx.tap.subscribe(onNext: {
            self.navigationController?.pushViewController(TableViewVC(), animated: true)
            }).disposed(by: disposeBag)
        
        collectionViewButton.rx.tap.subscribe(onNext: {
            self.navigationController?.pushViewController(CollectionViewVC(), animated: true)
            }).disposed(by: disposeBag)
        
        otherButton.rx.tap.subscribe(onNext: {
            self.navigationController?.pushViewController(OrdinaryTableViewVC(), animated: true)
            }).disposed(by: disposeBag)
    }
}
