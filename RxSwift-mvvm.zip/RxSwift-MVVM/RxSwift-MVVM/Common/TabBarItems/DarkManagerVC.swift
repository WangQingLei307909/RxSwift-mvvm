//
//  DarkManagerVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/4/1.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class DarkManagerVC: ViewController {

    @IBOutlet weak var followLabel: UILabel!
    @IBOutlet weak var darkLabel: UILabel!
    @IBOutlet weak var darkSwicth: UISwitch!
    @IBOutlet weak var followSwicth: UISwitch!
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.navigationItem.title = "暗黑模式"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selfDarkMode()
        darkSwicth.setOn(UserDefaults.standard.bool(forKey: "darkSwitchValue"), animated: true)
        followSwicth.setOn(UserDefaults.standard.bool(forKey: "systemSwitchValue"), animated: true)
    }
    
    @IBAction func darkAction(_ sender: UISwitch) {
        if #available(iOS 13.0, *) {
            let window = UIApplication.shared.delegate?.window!!
            window!.overrideUserInterfaceStyle = sender.isOn ? .dark : .light
            followSwicth.isOn = false
            UserDefaults.standard.set(sender.isOn, forKey: "darkSwitchValue")
            UserDefaults.standard.set(false, forKey: "systemSwitchValue")
        }

    }
    
    @IBAction func followAction(_ sender: UISwitch) {
        if #available(iOS 13.0, *) {
            let window = UIApplication.shared.delegate?.window!!
            window!.overrideUserInterfaceStyle = sender.isOn ? .unspecified : .light
            UserDefaults.standard.set(sender.isOn, forKey: "systemSwitchValue")
        }
    }

}

extension DarkManagerVC {
    func selfDarkMode()  {
        if #available(iOS 11.0, *) {
            self.view.backgroundColor = UIColor(named: "bgcolor")
            darkLabel.textColor   = UIColor(named: "titlecolor")
            followLabel.textColor = UIColor(named: "titlecolor")
        } else {
            self.view.backgroundColor = SwiftColor.bgViewColor
            darkLabel.textColor   = SwiftColor.TitleColor
            followLabel.textColor = SwiftColor.TitleColor
        }
    }
}
