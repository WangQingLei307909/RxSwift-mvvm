//
//  ThreadVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/25.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class ThreadVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    let dataSource   = ["『GCD』详尽总结","『RunLoop』详尽总结","『NSOperation、NSOperationQueue』详尽总结","『Runtime』详尽总结"]
    let cellIdentify = "WGIOSKnowViewCell"
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.navigationItem.title = "多线程"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
    }
    
    func setUpTableView() {
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
}

extension ThreadVC: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSource[indexPath.row])
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
            case 0:
                let vc = WGIOS_GCD_VC()
                vc.title = dataSource[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: true)
            break
            case 1:
                let vc = WGIOS_Runloop_VC()
                vc.title = dataSource[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: true)
            break
            case 2:
                let vc = WGIOS_Operation_Queue_VC()
                vc.title = dataSource[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: true)
            break
            case 3:
                let vc = WGIOS_Runtime_VC()
                vc.title = dataSource[indexPath.row]
                self.navigationController?.pushViewController(vc, animated: true)
            break
            default:
            break
        }
        
    }
    
}
