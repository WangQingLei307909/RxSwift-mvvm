//
//  MyVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/24.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class MyVC: ViewController {

    @IBOutlet var tap1: UITapGestureRecognizer!
    @IBOutlet var tap2: UITapGestureRecognizer!
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var button: UIButton!
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.navigationItem.title = "二维码扫描、识别、生成"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
        //识别二维码
        tap1.rx.event.subscribe(onNext: { [weak self](recognizer) in
            self!.identificationOfQRCode()
            }).disposed(by: disposeBag)
        
        //扫一扫
        tap2.rx.event.subscribe(onNext: { [weak self](recognizer) in
            let max: UInt32 = 4
            let min: UInt32 = 0
            let arc = arc4random_uniform(max - min) + min

            switch arc {
            case 0:
                self!.imageView2.image = "普通二维码".generateQRCodeWithSize(size: self?.imageView2.frame.size.width)
                break
            case 1:
                self!.imageView2.image = "图片二维码".generateQRCodeWithLogo(logo: UIImage(named: "01.png"))
                break
            case 2:
                self!.imageView2.image = "彩色二维码".generateQRCode(size: self?.imageView2.frame.size.width, color: .yellow, bgColor: .red, logo: nil)
                break
            case 3:
                self!.imageView2.image = "彩色二维码".generateQRCode(size: self?.imageView2.frame.size.width, color: .yellow, bgColor: .red, logo: UIImage(named: "01.png"))
                break
            default:
                break
            }
            }).disposed(by: disposeBag)
        
        // 生成二维码
        button.rx.tap.subscribe(onNext: { [weak self] in
//            let qrCodeScan = QRCodeScanVC()
            let qrCodeScan = ScanViewController()
            qrCodeScan.title = "扫一扫"
            self!.navigationController?.pushViewController(qrCodeScan, animated: true)
            }).disposed(by: disposeBag)
    }

    // MARK: - 识别图中二维码
    func identificationOfQRCode() {
        //解包
        guard let image = imageView1.image else { return }
        let result = QRCodeTool.detectorQRCode(image: image, isDrawQRCodeFrame: true)
        let strArr = result.resultStrs
        let resultImage = result.resultImage
        imageView1.image = resultImage
        let alertVC = UIAlertController(title: "结果", message: strArr?.description, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "关闭", style: .default) { (action : UIAlertAction) in
            self.dismiss(animated: true, completion: nil)
        }
        alertVC.addAction(cancelAction)
        present(alertVC, animated: true, completion: nil)
    }
    
    
}
