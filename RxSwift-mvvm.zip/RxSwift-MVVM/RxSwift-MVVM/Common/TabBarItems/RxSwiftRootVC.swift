//
//  RxSwiftRootVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class RxSwiftRootVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    lazy var dataSource: Array<String> = {
        let array = ["TableView",
                     "UICollectionView",
                     "其他控件的简单使用",
                     "登录",
                     "Subjects",
                     "Variable",
                     "doOn",
                     "Dispose",
                     "bindto",
                     "变化操作符",
                     "条件和布尔操作符",
                     "结合操作符",
                     "算数聚合操作符",
                     "连接操作符",
                     "其他操作符",
                     "错误处理",
                     "调试操作",
                     "特征序列 - 1",
                     "特征序列 - 2",
                     "Driver",
                     "Schedulers"]
        return array
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        self.tabBarController?.navigationItem.title = "RxSwift + Moya + MVVM + 应用"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
    }
    
}

extension RxSwiftRootVC: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if  cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        cell?.backgroundColor = .clear
        cell?.selectionStyle = .none
        cell?.textLabel?.textColor  = indexPath.row == 0 || indexPath.row == 1 ? .red : .randomColor()
        cell?.textLabel?.font = UIFont.boldSystemFont(ofSize: indexPath.row == 0 || indexPath.row == 1 ? 18 : 15)
        cell?.detailTextLabel?.text = indexPath.row == 0 || indexPath.row == 1 ? "MVVM + Moya + RxSwift" : ""
        cell?.detailTextLabel?.textColor = .orange
        cell?.textLabel?.text = "RxSwift - " + dataSource[indexPath.row]
        cell?.accessoryType = .disclosureIndicator
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            let vc = TableViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 1:
            let vc = CollectionViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 2:
            let vc = OrdinaryTableViewVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
            let vc = RxSwiftLoginVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
            let vc = RxSwiftSubjectsVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 5:
            let vc = RxSwiftVariableVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 6:
            let vc = RxSwiftdoOnVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 7:
            let vc = RxSwiftDisposeVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 8:
            let vc = RxSwiftBindtoVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 9:
            let vc = RxSwiftTransformingVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 10:
            let vc = RxSwiftFilterBoolVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 11:
            let vc = RxSwiftCombiningVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 12:
            let vc = RxSwiftMathematicalAggregateVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 13:
            let vc = RxSwiftConnectableVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 14:
            let vc = RxSwiftObservableUtilityVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 15:
            let vc = RxSwiftErrorVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 16:
            let vc = RxSwiftDebugVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 17:
            let vc = RxSwiftTraits1VC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 18:
            let vc = RxSwiftControlPropertyVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 19:
            let vc = RxSwiftDriverVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 20:
            let vc = RxSwiftSchedulersVC()
            vc.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(vc, animated: true)
            break
        default:
            break
        }
        
    }
    
}
