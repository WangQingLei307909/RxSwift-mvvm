//
//  RxSwiftDisposeVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/24.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftDisposeVC: ViewController {

    @IBOutlet weak var disposeButton: UIButton!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()

        disposeButton.rx.tap.subscribe(onNext: {
            let observable = Observable.from(["1","2","3"])
            observable.subscribe(onNext: { event in
                print(event)
            }).disposed(by: self.disposeBag)
        }).disposed(by: disposeBag)
        
    }


}
