//
//  RxSwiftSubjectsVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/24.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftSubjectsVC: ViewController {

    @IBOutlet weak var PublishSubjectButton: UIButton!
    @IBOutlet weak var BehaviorSubjectButton: UIButton!
    @IBOutlet weak var ReplaySubjectButton: UIButton!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()

        PublishSubjectButton.rx.tap.subscribe(onNext: { [weak self] in
            self?.PublishSubjects()
            }).disposed(by: disposeBag)
        
        BehaviorSubjectButton.rx.tap.subscribe(onNext: { [weak self] in
            self?.BehaviorSubjects()
            }).disposed(by: disposeBag)
        
        ReplaySubjectButton.rx.tap.subscribe(onNext: { [weak self] in
            self?.ReplaySubjects()
            }).disposed(by: disposeBag)
        
    }

    // MARK: - 说到Subjects，Subjects有一个属性，就是Subjects 既是订阅者，也是 Observable，也就是说他自己可以发送消息，也可以接受消息
    func PublishSubjects() {
        // 1. PublishSubject  不需要初值就可以创建
        let subject = PublishSubject<String>()
        subject.onNext("PublishSubjects 第一次发送消息")
        subject.subscribe(onNext: { ( string ) in
            print("PublishSubjects 第一次订阅")
        }, onError: { ( error ) in
            
        }, onCompleted: {
            print("PublishSubjects 第一次完成")
        }).disposed(by: disposeBag)
        
        
        subject.onNext("PublishSubjects 第二次发送消息")
        subject.subscribe(onNext: { ( string ) in
            print("PublishSubjects 第二次订阅")
        }, onError: { ( error ) in
            
        }, onCompleted: {
            print("PublishSubjects 第二次完成")
        }).disposed(by: disposeBag)
        
        subject.onNext("PublishSubjects 其他情况测试")
        
        //当PublishSubject 执行完onCompleted后，再次订阅只会收到完成操作，在发送其他消息都无法接受
        subject.onCompleted()
        
        subject.onNext("PublishSubjects 第三次发送消息")
        subject.subscribe(onNext: { ( string ) in
            print("PublishSubjects 第三次订阅")
        }, onError: { ( error ) in
            
        }, onCompleted: {
            print("PublishSubjects 第三次完成")
        }).disposed(by: disposeBag)
        /*
         通过打印结果，我们不难看出，PublishSubject有四个特点
         1、就是创建的时候不需要初始值
         2、默认自动会走一遍订阅消息，也就是我么看到会出现两次 -> PublishSubjects 第一次订阅
         3、当PublishSubject 执行完onCompleted后，再次订阅只会收到完成操作，在发送其他消息都无法接受
         3、当PublishSubject 发送消息是，只会在下一次订阅的位置收到消息，其他订阅位置无法收到消息
         */
    }

    func BehaviorSubjects() {
        // 2 BehaviorSubject 需要一个默认值来创建
        let subject = BehaviorSubject(value: "BehaviorSubject 初始值")
        subject.subscribe { (event) in
            print("BehaviorSubject 第一次订阅",event)
            }.disposed(by: disposeBag)
        
        subject.onNext("BehaviorSubject 第二次发送消息")
        
        subject.onError(NSError(domain: "local", code: 0, userInfo: nil))
        
        subject.subscribe { (event) in
            print("BehaviorSubject 第二次订阅", event)
            }.disposed(by: disposeBag)
        /*
         通过打印结果，我们不难看出，BehaviorSubjects有三个特点
         1、就是创建的时候需要初始值
         2、自动走一遍初始值
         3、当发送消息的时候，只要涉及到订阅的地方都会走一遍订阅
         */
    }
    
    func ReplaySubjects() {
        // 3 ReplaySubject  buffersize设置次数
        let subject = ReplaySubject<String>.create(bufferSize: 2)
        //        连续发3个事件
        subject.onNext("ReplaySubject 第一次发送消息")
        subject.onNext("ReplaySubject 第二次发送消息")
        subject.onNext("ReplaySubject 第三次发送消息")
        
        subject.subscribe { (event) in
            print("第一次订阅", event)
            }.disposed(by: disposeBag)
        
        subject.onNext("ReplaySubject 第四次发送消息")
        
        
        subject.subscribe { (event) in
            print("第二次订阅", event)
            }.disposed(by: disposeBag)
        
        subject.onCompleted()
        
        subject.subscribe { (event) in
            print("第三次订阅", event)
            }.disposed(by: disposeBag)
        
        /*
         通过打印结果，我们不难看出，ReplaySubject有两个特点
         1、就是创建的时候需要设置数量，如果设置为2个，当我们订阅发送三次的时候会自动取最新的两次
         2、当发送消息的时候，只要涉及到订阅的地方都会走一遍订阅
         */
        
    }
    
}
