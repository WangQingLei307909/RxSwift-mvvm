//
//  UIGestureRecognizerVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
class UIGestureRecognizerVC: ViewController {
    
    @IBOutlet var swipe: UISwipeGestureRecognizer!
    @IBOutlet var tap: UITapGestureRecognizer!
    @IBOutlet var long: UILongPressGestureRecognizer!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        swipe.rx.event.subscribe(onNext: { [weak self] recognizer in
            let point = recognizer.location(in: recognizer.view)
            self!.showAlert(title: "向右滑动", message: "\(point.x),\(point.y)")
            }).disposed(by: disposeBag)
        
        tap.rx.event.subscribe(onNext: {  [weak self] recognizer in
            let point = recognizer.location(in: recognizer.view)
            self!.showAlert(title: "点击了", message: "\(point.x),\(point.y)")
            }).disposed(by: disposeBag)
        
        long.rx.event.subscribe(onNext: {  [weak self] recognizer in
            let point = recognizer.location(in: recognizer.view)
            self!.showAlert(title: "长按了", message: "\(point.x),\(point.y)")
            }).disposed(by: disposeBag)
        
    }
    
    //显示消息提示框
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .cancel))
        self.present(alert, animated: true)
    }
    
}
