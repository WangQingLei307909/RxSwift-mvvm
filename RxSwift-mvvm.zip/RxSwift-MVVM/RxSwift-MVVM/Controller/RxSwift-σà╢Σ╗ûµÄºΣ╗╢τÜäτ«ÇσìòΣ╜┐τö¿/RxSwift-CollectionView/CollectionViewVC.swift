//
//  CollectionViewVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import MJRefresh
import RxDataSources
class CollectionViewVC: ViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    let anachorVM = AnchorViewModel()
    
    let disposeBag = DisposeBag()
    
    lazy var flowLayout: UICollectionViewFlowLayout = {
        var layout = UICollectionViewFlowLayout.init()
        layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
        layout.minimumLineSpacing = 2
        layout.minimumInteritemSpacing = 2
        return layout
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "CollectionViewController"
        setUpCollectionView()
    }

    func setUpCollectionView() {
        collectionView.register(UINib(nibName: "RxCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "RxCollectionViewCell")
        collectionView.collectionViewLayout = flowLayout
        let dataSuource = RxCollectionViewSectionedReloadDataSource<AnchorSection>(configureCell: { dataSource, collectionView, indexPath, element -> RxCollectionViewCell in
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RxCollectionViewCell", for: indexPath) as! RxCollectionViewCell
            cell.anchorModel = element
            return cell
        })
        let vmInput = AnchorViewModel.WeiInput(category: .getHomeList(page: 1))
        let vmOutput = anachorVM.tranform(input: vmInput)
        vmOutput.requestCommond.onNext(true)
        collectionView.mj_header = MJRefreshNormalHeader(refreshingBlock: {
            vmOutput.requestCommond.onNext(true)
        })
        collectionView.mj_footer = MJRefreshBackNormalFooter(refreshingBlock: {
            vmOutput.requestCommond.onNext(false)
        })
        vmOutput.sections.asDriver().drive(collectionView.rx.items(dataSource: dataSuource)).disposed(by: disposeBag)
        vmOutput.refreshStatus.asObservable().subscribe(onNext: { [weak self] status in
            switch status {
            case .beingHeaderRefresh:
                self!.collectionView.mj_header!.beginRefreshing()
            case .endHeaderRefresh:
                self!.collectionView.mj_header!.endRefreshing()
            case .beingFooterRefresh:
                self!.collectionView.mj_footer!.beginRefreshing()
            case .endFooterRefresh:
                self!.collectionView.mj_footer!.endRefreshing()
            case .noMoreData:
                self!.collectionView.mj_footer!.endRefreshingWithNoMoreData()
            default:
                break
            }
        }).disposed(by: disposeBag)
        collectionView.rx.modelSelected(AnchorModel.self).subscribe(onNext: { ( model ) in
            
        }).disposed(by: disposeBag)
    }
    
}
