//
//  CollectionViewVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import MJRefresh
import RxDataSources

class CollectionViewVC: ViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    let anachorVM = AnchorViewModel()
    let disposeBag = DisposeBag()
    let itemWidth: CGFloat = (kScreenWidth - 6) / 3
    lazy var flowLayout: UICollectionViewFlowLayout = {
        var layout = UICollectionViewFlowLayout.init()
        layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
        layout.minimumLineSpacing = 2
        layout.minimumInteritemSpacing = 2
        return layout
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "CollectionViewController"
        setUpCollectionView()
    }

    func setUpCollectionView() {
        collectionView.register(UINib(nibName: "RxCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "RxCollectionViewCell")
        collectionView.collectionViewLayout = flowLayout
        //通过RxDataSource cell的上的数据展示
        let dataSuource = RxCollectionViewSectionedReloadDataSource<AnchorSection>(configureCell: { dataSource, collectionView, indexPath, element -> RxCollectionViewCell in
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RxCollectionViewCell", for: indexPath) as! RxCollectionViewCell
            cell.anchorModel = element
            return cell
        })
        //创建WeiInput并设置初始值
        let vmInput = AnchorViewModel.WeiInput(category: .getHomeList(page: 1))
        // 将Input通过tranform方法传递viewModel
        let vmOutput = anachorVM.tranform(input: vmInput)
        //请求数据
        vmOutput.requestCommond.onNext(true)
        /*
        collectionView添加刷新
        */
        collectionView.mj_header = MJRefreshNormalHeader(refreshingBlock: {
            vmOutput.requestCommond.onNext(true)
        })
        /*
        collectionView添加加载
        */
        collectionView.mj_footer = MJRefreshBackNormalFooter(refreshingBlock: {
            vmOutput.requestCommond.onNext(false)
        })
        /*
         vmOutput通过请求处理并将内容赋给vmOutput里的sections
         将vmOutput.sections转化为Driver()
         */
        vmOutput.sections.asDriver().drive(collectionView.rx.items(dataSource: dataSuource)).disposed(by: disposeBag)
        /*
         对vmOutput结构体内的refreshStatus进行订阅。
         当vmOutput的refreshStatus发生变化是，这里就会收到对应的状态
         根据对应的状态，更改tableView的刷新、加载对应状态
         */
        vmOutput.refreshStatus.asObservable().subscribe(onNext: { [weak self] status in
            switch status {
            case .beingHeaderRefresh:
                self!.collectionView.mj_header!.beginRefreshing()
            case .endHeaderRefresh:
                self!.collectionView.mj_header!.endRefreshing()
            case .beingFooterRefresh:
                self!.collectionView.mj_footer!.beginRefreshing()
            case .endFooterRefresh:
                self!.collectionView.mj_footer!.endRefreshing()
            case .noMoreData:
                self!.collectionView.mj_footer!.endRefreshingWithNoMoreData()
            default:
                break
            }
        }).disposed(by: disposeBag)
        collectionView.rx.modelSelected(AnchorModel.self).subscribe(onNext: { ( model ) in
            
        }).disposed(by: disposeBag)
    }
    
}
