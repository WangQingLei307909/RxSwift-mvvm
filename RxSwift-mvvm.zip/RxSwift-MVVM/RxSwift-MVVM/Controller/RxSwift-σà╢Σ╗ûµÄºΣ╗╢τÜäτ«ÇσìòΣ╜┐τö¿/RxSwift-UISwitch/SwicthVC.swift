//
//  SwicthVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class SwicthVC: ViewController {

    @IBOutlet weak var switchs: UISwitch!
    @IBOutlet weak var button: UIButton!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()

        //Switch的点击事件
        switchs.rx.isOn.subscribe(onNext: { (flag) in
                print("switch -> \(flag)")
            }).disposed(by: disposeBag)
        
        //将switch的点击绑定到button上
        switchs.rx.isOn.bind(to: button.rx.isEnabled).disposed(by: disposeBag)
        
        //通过swicth来禁止和打开按钮的点击事件
        button.rx.tap.subscribe(onNext: {
            print("button -> 可以点击")
        }).disposed(by: disposeBag)
        
    }

}
