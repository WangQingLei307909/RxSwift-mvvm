//
//  StepperVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class StepperVC: ViewController {
    @IBOutlet weak var stepper: UIStepper!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        stepper.rx.value.subscribe(onNext: { ( value ) in
            print("点击了\(value)个按钮")
            }).disposed(by: disposeBag)
    }

}
