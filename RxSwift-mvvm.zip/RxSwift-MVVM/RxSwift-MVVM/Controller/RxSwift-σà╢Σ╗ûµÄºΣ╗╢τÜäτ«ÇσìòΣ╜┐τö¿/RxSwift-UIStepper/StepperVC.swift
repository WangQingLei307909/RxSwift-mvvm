//
//  StepperVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class StepperVC: ViewController {
    @IBOutlet weak var stepper: UIStepper!
    let label = UILabel()
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        stepper.rx.value.subscribe(onNext: { ( value ) in
            print("当前值：\(value)")
            }).disposed(by: disposeBag)
        
        stepper.rx.value.map {
            "\($0)"
            }.bind(to: label.rx.text).disposed(by: disposeBag)
        
    }

}
