//
//  SliderVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class SliderVC: ViewController {

    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var stepper: UIStepper!
    let label = UILabel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        slider.rx.value.subscribe(onNext: { ( value ) in
            print("滑块当前值为：\(value)")
            }).disposed(by: disposeBag)
        
        slider.rx.value.map {
            Double($0)
            }.bind(to: stepper.rx.stepValue).disposed(by: disposeBag)
        slider.rx.value.map { "\($0)" }.bind(to: label.rx.text).disposed(by: disposeBag)
    }

}
