//
//  OrdinaryTableViewVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

// MARK: - 不是RxSwift

class OrdinaryTableViewVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    lazy var dataSource: Array<String> = {
        let array = ["UILabel",
                     "UIButton",
                     "UISwitch",
                     "UISegmentedControlVC",
                     "UISlider","UIStepper",
                     "UIGestureRecognizer",
                     "UIDatePicker"]
        return array
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}

extension OrdinaryTableViewVC: UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if  cell == nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        }
        cell?.selectionStyle = .none
        cell?.accessoryType = .disclosureIndicator
        cell?.textLabel?.textColor = .randomColor()
        cell?.textLabel?.text = dataSource[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            let label = LabelVC()
            label.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(label, animated: true)
            break
        case 1:
            let button = ButtonVC()
            button.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(button, animated: true)
            break
        case 2:
            let swicth = SwicthVC()
            swicth.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(swicth, animated: true)
            break
        case 3:
            let segmentedControl = SegmentedControlVC()
            segmentedControl.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(segmentedControl, animated: true)
            break
        case 4:
            let slider = SliderVC()
            slider.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(slider, animated: true)
            break
        case 5:
            let stepper = StepperVC()
            stepper.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(stepper, animated: true)
            break
        case 6:
            let gestureRecognizer = UIGestureRecognizerVC()
            gestureRecognizer.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(gestureRecognizer, animated: true)
            break
        case 7:
            let datePicker = DatePickerVC()
            datePicker.title = dataSource[indexPath.row]
            self.navigationController?.pushViewController(datePicker, animated: true)
            break
        default:
            break
        }

    }
    
}
