//
//  TableViewVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import MJRefresh
import RxDataSources
import SYPhotoBrowser
class TableViewVC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!

    let viewModel = AnchorGirlViewModel()
    let disposeBags = DisposeBag()
    //设置订阅请求类别（所有等）
    var category = BehaviorRelay<NetworkTool.GirlCategory>(value: .GirlCategoryAll)
    //设置viewModel输出对象
    var vmOutput: AnchorGirlViewModel.Output? = nil
    
    override func viewDidLoad(){
        super.viewDidLoad()
        darkMode()
        navigationItem()
        setUpTableView()
    }
    
    fileprivate func navigationItem(){
        /*
         添加筛选导航
         */
        let dropdownMenu = SYNavigationDropdownMenu(navigationController: self.navigationController!)
        dropdownMenu!.dataSource = self
        dropdownMenu!.delegate = self
        self.navigationItem.titleView = dropdownMenu
    }
    
    func setUpTableView() {
        tableView.register(UINib(nibName: "RxTableViewCell", bundle: nil), forCellReuseIdentifier: "RxTableViewCell")
        //通过RxDataSource cell的上的数据展示
        let dataSource = RxTableViewSectionedReloadDataSource<AnchorSection>(
            configureCell: { (dataSource, tableView, indexPath, itemModel) in
                let cell = tableView.dequeueReusableCell(withIdentifier: "RxTableViewCell", for: indexPath) as! RxTableViewCell
                cell.anchorModel = itemModel
                cell.accessoryType = .disclosureIndicator
                return cell
            }
            
            //MARK:- 设置分组功能，如果不适用分组下面代码注释掉
            /*
             , titleForHeaderInSection: { data ,sectionIndex in
                 return data[sectionIndex].title
             }
             */
        )
        
        //将上面创建category 赋值给viewModel的WeiInput的结构体
        let vmInput = AnchorGirlViewModel.WeiInput(category: category)
        // 将Input通过tranform方法传递viewModel
        vmOutput = viewModel.tranform(input: vmInput)
        /*
         对vmOutput结构体内requestCommond进行消息发送。
         而对requestCommond进行订阅的地方就会自行调用数据请求或者进行其他操作
         */
        vmOutput!.requestCommond.onNext(true)
        vmOutput!.sections.asDriver().drive(tableView.rx.items(dataSource: dataSource)).disposed(by: disposeBags)
        /*
         在上面方法中我们可以看到我们根本无法发现tableView的数据源，因为这里已经通过Driver绑定到了dataSource上
         那我们要使用数据源要怎么办呢？
         其实很简单我们只需要使用下面代码即可
         */
        // MARK: -
        /*
         在ViewModel中我们定义了Variable存储数据源，Variable是可以作为观察者的。
         所以这里我们只需要将ViewModel的数据源作为观察者并订阅即可。
         当数据源发生变化的时候，我们就可以在subscribe订阅的闭包内收到请求的数据
         */
        viewModel.anchorArr.asObservable().subscribe(onNext: { arrayList in
            print("arrayList ---------------",arrayList)
            }).disposed(by: disposeBags)
        /*
         对vmOutput结构体内的refreshStatus进行订阅。
         当vmOutput的refreshStatus发生变化是，这里就会收到对应的状态
         根据对应的状态，更改tableView的刷新、加载对应状态
         */
        vmOutput!.refreshStatus.asObservable().subscribe(onNext: { [weak self] status in
            switch status {
            case .beingHeaderRefresh:
                self!.tableView.mj_header!.beginRefreshing()
            case .endHeaderRefresh:
                self!.tableView.mj_header!.endRefreshing()
            case .beingFooterRefresh:
                self!.tableView.mj_footer!.beginRefreshing()
            case .endFooterRefresh:
                self!.tableView.mj_footer!.endRefreshing()
            case .noMoreData:
                self!.tableView.mj_footer!.endRefreshingWithNoMoreData()
            default:
                break
            }
        }).disposed(by: disposeBags)
        /*
         tableView的点击事件
         */
        tableView.rx.modelSelected(AnchorModel.self).subscribe(onNext: { ( model ) in
            print("current selected model is \(model)")
            let photoBrowser: SYPhotoBrowser = SYPhotoBrowser(imageSourceArray: [model.image_url], caption: nil, delegate: self)
            UIApplication.shared.delegate?.window?!.rootViewController?.present(photoBrowser, animated: true)
        }).disposed(by: disposeBags)
        /*
         tableView添加刷新
         */
        tableView.mj_header = MJRefreshNormalHeader(refreshingBlock: {
            self.vmOutput!.requestCommond.onNext(true)
        })
        /*
         tableView添加加载
         */
        tableView.mj_footer = MJRefreshAutoNormalFooter(refreshingBlock: {
            self.vmOutput!.requestCommond.onNext(false)
        })
        //tableView遵守协议
        tableView.rx.setDelegate(self)
    }
}

extension TableViewVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return RxTableViewCell.height()
    }
}

extension TableViewVC: SYNavigationDropdownMenuDataSource, SYNavigationDropdownMenuDelegate{
    
    func titleArray(for navigationDropdownMenu: SYNavigationDropdownMenu!) -> [String]! {
        return ["所有", "大胸", "翘臀", "黑丝", "美腿", "清新", "杂烩"]
    }
    
    func arrowImage(for navigationDropdownMenu: SYNavigationDropdownMenu!) -> UIImage! {
        return UIImage.init(named: "Arrow")
    }
    
    func arrowPadding(for navigationDropdownMenu: SYNavigationDropdownMenu!) -> CGFloat {
        return 8.0
    }
    
    func keepCellSelection(for navigationDropdownMenu: SYNavigationDropdownMenu!) -> Bool {
        return false
    }
    
    func navigationDropdownMenu(_ navigationDropdownMenu: SYNavigationDropdownMenu!, didSelectTitleAt index: UInt) {
        /*
         对category进行肤质，而对其进行订阅的位置便会收到对应的内容，并进行对应的操作
         */
        self.category.accept(NetworkTool.indexToCategory(index: Int(index)))
        //点击就开始刷新
        self.tableView.mj_header!.beginRefreshing()
    }
    
}
