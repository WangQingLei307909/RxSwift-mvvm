//
//  ButtonVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class ButtonVC: ViewController {

    @IBOutlet weak var RxSwiftButton: UIButton!
    @IBOutlet weak var oneButton: UIButton!
    @IBOutlet weak var twoButton: UIButton!
    @IBOutlet weak var threeButton: UIButton!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        RxSwiftButton.rx.tap.subscribe(onNext: { [weak self] in
            self!.showMessage("RxSwift写法被点击")
            self!.bindToButton()
            }).disposed(by: disposeBag)
        moreButton()
    }
    
    @IBAction func ordinaryAction(_ sender: Any) {
        showMessage("普通版本的点击事件")
    }
    
    
    //显示消息提示框
    func showMessage(_ text: String) {
        let alertController = UIAlertController(title: text, message: nil, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "确定", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK:- Button 内容 图片的绑定
    func bindToButton() {
        //普通的文本绑定
        let timer = Observable<Int>.interval(1, scheduler: MainScheduler.instance)
        timer.map { return "计算时间：\($0)" }.bind(to: RxSwiftButton.rx.title()).disposed(by: disposeBag)
//        //富文本
//        timer.map(bindAttributedTitle(ms:)).bind(to: RxSwiftButton.rx.attributedTitle()).disposed(by: disposeBag)
//        //绑定图片
//        timer.map({
//            let string = $0 % 2 == 1 ? "img_operation_success" : "img_operation_failure"
//            return UIImage(named: string)!
//            }).bind(to: RxSwiftButton.rx.image()).disposed(by: disposeBag)
//        //绑定背景图片
//        timer.map({
//            let string = $0 % 2 == 1 ? "img_operation_success" : "img_operation_failure"
//            return UIImage(named: string)!
//            }).bind(to: RxSwiftButton.rx.backgroundImage()).disposed(by: disposeBag)
    }
    
    //    将数字转成对应的富文本
    func bindAttributedTitle(ms: NSInteger) -> NSMutableAttributedString {
        let string = String(format: "%0.2d:%0.2d.%0.1d",
                            arguments: [(ms / 600) % 600, (ms % 600 ) / 10, ms % 10])
        //富文本设置
        let attributeString = NSMutableAttributedString(string: string)
        //从文本0开始6个字符字体HelveticaNeue-Bold,16号
        attributeString.addAttribute(NSAttributedString.Key.font,
                                     value: UIFont(name: "HelveticaNeue-Bold", size: 16)!,
                                     range: NSMakeRange(0, 5))
        //设置字体颜色
        attributeString.addAttribute(NSAttributedString.Key.foregroundColor,
                                     value: UIColor.white, range: NSMakeRange(0, 5))
        //设置文字背景颜色
        attributeString.addAttribute(NSAttributedString.Key.backgroundColor,
                                     value: UIColor.orange, range: NSMakeRange(0, 5))
        return attributeString
    }
    
    // MARK: - 见Switch点开关时间绑定到Button的是否能使用事件上
    @IBAction func switchAction(_ sender: UISwitch) {
        sender.rx.isOn.bind(to: RxSwiftButton.rx.isEnabled).disposed(by: disposeBag)
    }
    
    // MARK: - 多个按钮之间的点击事件
    func moreButton() {
        let btns = [oneButton,twoButton,threeButton].map({$0!})
        let selectButton = Observable.from(btns.map({ btn in
            btn.rx.tap.map({btn})
            })).merge()
        for button in btns {
            selectButton.map {
                $0 == button
            }.bind(to: button.rx.isSelected).disposed(by: disposeBag)
        }
    }
}
