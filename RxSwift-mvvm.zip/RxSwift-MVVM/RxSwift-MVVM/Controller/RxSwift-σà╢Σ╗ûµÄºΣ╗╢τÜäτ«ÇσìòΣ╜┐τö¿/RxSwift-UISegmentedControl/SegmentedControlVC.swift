//
//  SegmentedControlVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class SegmentedControlVC: ViewController {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var imageViews: UIImageView!
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //点击事件
        segmentedControl.rx.selectedSegmentIndex.subscribe(onNext: { ( selectIndex ) in
            print("点击了第\(selectIndex)个按钮")
            }).disposed(by: disposeBag)
        //创建一个当前需要显示的图片的可观察序列
        let imageObserver: Observable<UIImage> = segmentedControl.rx.selectedSegmentIndex.asObservable().map({
                let images = ["img_operation_failure", "img_operation_success"]
                return UIImage(named: images[$0])!
            })
        imageObserver.bind(to: imageViews.rx.image).disposed(by: disposeBag)
    
    
    
    }


}
