//
//  RxSwiftdoOnVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/24.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftdoOnVC: ViewController {

    @IBOutlet weak var doOnButton: UIButton!
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        /*
         doOn 是用来监听事件的生命周期，它会在每一次事件发送前被调用
         doOn 和 subscribe 是一样的
         do(onNext:) 会在 subscribe(onNext:) 前调用
         do(onCompleted:) 会在 subscribe(onCompleted:) 前面调用
         */
        doOnButton.rx.tap.subscribe(onNext: {
            let observable = Observable.of(11,22,33)
            observable.do(onNext: { element in
                print("do-->",element)
            }, onError: { error in
                print("do-->",error)
            }, onCompleted: {
                print("do ---> completed")
            }, onDispose: {
                print("do --->Disposed")
            }).subscribe(onNext: { event in
                    print("subscribe",event)
                }, onError: { error in
                    print("subscribe",error)
                }, onCompleted: {
                    print("subscribe completed")
                }, onDisposed: {
                    print("subscribe Disposed")
                })
            }).disposed(by: disposeBag)

    }

    
}
