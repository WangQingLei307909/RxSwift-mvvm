//
//  RxSwiftLoginVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftLoginVC: ViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "登录"
        nameTextField.layer.borderWidth = 1
        nameTextField.layer.cornerRadius = 5
        passwordTextField.layer.masksToBounds = true
        passwordTextField.layer.borderWidth = 1
        
        let userObservable = nameTextField.rx.text.map({ InputValidator.isValidEmail($0!) })
        userObservable.map({ $0 ? UIColor.green : UIColor.clear })
            .subscribe(onNext: { self.nameTextField.layer.borderColor = $0.cgColor })
            .disposed(by: disposeBag)

        let passObservable = passwordTextField.rx.text.map({ InputValidator.isValidEmail($0!) })
        passObservable.map({ $0 ? UIColor.green : UIColor.clear })
            .subscribe(onNext: { self.passwordTextField.layer.borderColor = $0.cgColor })
            .disposed(by: disposeBag)
        
        Observable.combineLatest(userObservable, passObservable) { (varildUser, varildPass) -> Bool in
            return varildPass && varildUser
        }.subscribe(onNext: { (isEnable) in
            self.loginButton.isEnabled = isEnable
            }).disposed(by: disposeBag)
        
        loginButton.rx.tap.subscribe(onNext: { [unowned self] in
            self.navigationController?.popViewController(animated: true)
        }).disposed(by: disposeBag)
        
        registerButton.rx.tap.subscribe(onNext: {
            self.navigationController?.pushViewController(RxSwiftRegisterVC(), animated: true)
            }).disposed(by: disposeBag)
    }

}

