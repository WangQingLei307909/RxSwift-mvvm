//
//  RxSwiftRegisterVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftRegisterVC: ViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var usernameHintLabel: UILabel!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var passwordHintLabel: UILabel!
    @IBOutlet weak var passwordRepeatTextField: UITextField!
    @IBOutlet weak var passwordRepeatLabel: UILabel!
    
    @IBOutlet weak var registerBtn: UIButton!
    
    let disposeBag = DisposeBag()
    let registerVM = RegisterViewModel()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "注册"
        
        //1. 账号判断逻辑
        //1-1. 检测账号
        usernameTextField.rx.text
            .orEmpty // 将String? 类型转为String型
            .bind(to: registerVM.username)
            .disposed(by: disposeBag)
        
        //1-2. 根据账号监听提示字体的状态
        registerVM.usernameObserable
            .bind(to: usernameHintLabel.rx.validationResult)
            .disposed(by: disposeBag)
        
        //1-3. 根据账号监听密码输入框的状态
        registerVM.usernameObserable
            .bind(to: passwordTextField.rx.enableResult)
            .disposed(by: disposeBag)
        
        
        
        //2. 密码判断逻辑
        passwordTextField.rx.text.orEmpty.bind(to: registerVM.password).disposed(by: disposeBag)
        
        //2-1. 根据密码字符串监听密码提示信息的显示状态
        registerVM.passwordObserable.bind(to: passwordHintLabel.rx.validationResult).disposed(by: disposeBag)
        
        //2-2.根据密码字符串监听密码重复密码输入框的状态
        registerVM.passwordObserable.bind(to: passwordRepeatTextField.rx.enableResult).disposed(by: disposeBag)
        
        
        
        //3. 重复输入密码逻辑
        passwordRepeatTextField.rx.text.orEmpty.bind(to: registerVM.repeatPassword).disposed(by: disposeBag)
        
        //3-1. 根据重复密码字符串监听密码提示信息的显示状态
        registerVM.repeatPassObserable.bind(to: passwordRepeatLabel.rx.validationResult).disposed(by: disposeBag)
        
        
        
        //4. 处理按钮点击事件
        //4-1. 按钮的状态(是否可点)
        registerVM.registerBtnObserable.bind(to: registerBtn.rx.isEnabled).disposed(by: disposeBag)
        registerVM.registerBtnObserable.bind(to: registerBtn.rx.backColorResult).disposed(by: disposeBag)

        //4-2. 监听注册按钮的点击
        registerBtn.rx.tap.subscribe({ (_) in
            self.navigationController?.popViewController(animated: true)
        }).disposed(by: disposeBag)
    }

}
