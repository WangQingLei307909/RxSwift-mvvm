//
//  WGIOS_GCD_VC.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/12.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
class WGIOS_GCD_VC: ViewController {

    enum SelectType : Int {
        case SyncConcurrent = 0
        case AsyncConcurrent = 1
        case SyncSerial = 2
        case AsyncSerial = 3
        case SyncMain = 4
        case AsyncMain = 5
    }
    let dispatchSemaphore = DispatchSemaphore(value: 1)
    var money = 10

    @IBOutlet weak var tableView: UITableView!
    var dataSource   = NSArray()
    let cellIdentify = "WGIOSKnowViewCell"
    public var titleString = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
        creatDataSource()
    }

    func setUpTableView() {
        
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
    func creatDataSource() {
        dataSource = ["串行队列的创建方法",
                      "并发队列的创建方法",
                      "主队列的获取方法",
                      "全局并发队列的获取方法",
                      "同步执行任务创建方法",
                      "异步执行任务创建方法",
                      "同步执行 + 并发队列",
                      "异步执行 + 并发队列",
                      "同步执行 + 串行队列",
                      "异步执行 + 串行队列",
                      "同步执行 + 主队列",
                      "异步执行 + 主队列",
                      "GCD 线程间的通信",
                      "GCD 队列组：dispatch_group",
                      "GCD 栅栏方法：dispatch_barrier_async",
                      "GCD 延时执行方法：dispatch_after",
                      "dispatch_group_wait",
                      "dispatch_group_enter、dispatch_group_leave",
                      "GCD 信号量：dispatch_semaphore",
                      "非线程安全（不使用 semaphore）",
                      "线程安全（使用 semaphore 加锁）"]
    }

}

extension WGIOS_GCD_VC: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSource[indexPath.row] as! String)
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row >= 0 && indexPath.row <= 3 {
            gcdBase(index: indexPath.row)
        }
        if indexPath.row == 4 || indexPath.row == 5 {
            syncAndAsyncExecution(flag: indexPath.row == 4)
        }
        if indexPath.row >= 6 && indexPath.row <= 11 {
            tasksAndQueues(selectType: WGIOS_GCD_VC.SelectType(rawValue: indexPath.row - 6)!)
        }
        if indexPath.row == 12 {
            threadCommunication()
        }
        if indexPath.row == 13 {
            dispatchGroup()
        }
        if indexPath.row == 14 {
            queueBarrier()
        }
        if indexPath.row == 15 {
            dispatch_after()
        }
        if indexPath.row == 16 {
            dispatch_group_wait()
        }
        if indexPath.row == 17 {
            dispatch_group_enter_leave()
        }
        if indexPath.row == 18 {
            dispatch_semaphore()
        }
        if indexPath.row == 19 {
            dispatch_semaphore_money(flag: false)
        }
        if indexPath.row == 20 {
            dispatch_semaphore_money(flag: true)
        }
    }
    
}

// MARK: - 获取线程  同步+异步任务创建方法
extension WGIOS_GCD_VC{
    // MARK: - 获取线程
        func gcdBase(index:NSInteger) {
            if index == 0 {//创建串行队列
                //swift
                _ = DispatchQueue.init(label: "test", qos: .default, attributes: .init(rawValue: 0), autoreleaseFrequency: .workItem, target: nil)
                //串行队列，label名字随便取
                _ = DispatchQueue(label: "test")
                //oc
    //            dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_SERIAL);
            }
            if index == 1 {//创建并行队列
                //swift
                _ = DispatchQueue.init(label: "test", qos: .default, attributes: .concurrent, autoreleaseFrequency: .workItem, target: nil)
                //并行队列
                _ = DispatchQueue(label: "test", attributes: .concurrent)
                //oc
                //dispatch_queue_t queue = dispatch_queue_create("net.bujige.testQueue", DISPATCH_QUEUE_CONCURRENT);
            }
            if index == 2 {//主队列的获取方法
                //swift
                _ = DispatchQueue.main
                // oc
                //dispatch_queue_t queue = dispatch_get_main_queue();
            }
            if index == 3 {// 全局并发队列的获取方法
                //swift
                _ = DispatchQueue.global()
                //oc
                //dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
            }
            
        }
    // MARK: - 同步+异步任务创建方法
    func syncAndAsyncExecution(flag:Bool) {
        if flag {
            let queue = DispatchQueue.init(label: "同步任务创建方法")
            queue.sync {
                CLToast.cl_show(msg: "同步任务创建方法")
            }
        } else {
            let queue = DispatchQueue.main
            queue.async {
                CLToast.cl_show(msg: "异步任务创建方法")
            }
        }
        
    }
}
 // MARK: - 任务+队列
extension WGIOS_GCD_VC{
    // MARK: - 任务+队列
    func tasksAndQueues(selectType:SelectType) {
        switch selectType {
        case .SyncConcurrent://同步 + 并发
            let queue = DispatchQueue.global()
            print("begin=\(Thread.current)")
            queue.sync {
                Thread.sleep(forTimeInterval: 5)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 并发 + 5")
            }
            queue.sync {
                Thread.sleep(forTimeInterval: 3)
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 并发 + 3")
            }
            CLToast.cl_show(msg: "完成")
            break
        case .AsyncConcurrent://异步 + 并发
            let queue = DispatchQueue.global()
            print("begin=\(Thread.current)")
            queue.async {
                Thread.sleep(forTimeInterval: 5)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 并发 + 5")
            }
            queue.async {
                Thread.sleep(forTimeInterval: 1)
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 并发 + 1")
            }
            queue.async {
                Thread.sleep(forTimeInterval: 3)
                print("3=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 并发 + 3")
            }
            print("end===\(Thread.current)")
            CLToast.cl_show(msg: "完成")
            break
        case .SyncSerial://同步 + 串行
            let queue = DispatchQueue.init(label: "串行")
            print("begin=\(Thread.current)")
            queue.sync {
                Thread.sleep(forTimeInterval: 5)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 串行 + 5")
            }
            queue.sync {
                Thread.sleep(forTimeInterval: 3)
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 串行 + 3")
            }
            CLToast.cl_show(msg: "完成")
            break
        case .AsyncSerial: // 异步 + 串行
            let queue = DispatchQueue.init(label: "串行队列")
            print("begin=\(Thread.current)")
            queue.async {
                Thread.sleep(forTimeInterval: 5)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 串行 + 5")
            }
            queue.async {
                Thread.sleep(forTimeInterval: 3)
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 串行 + 3")
            }
            print("end===\(Thread.current)")
            CLToast.cl_show(msg: "完成")
            break
        case .SyncMain: // 同步 + 主队列
            let queue = DispatchQueue.main
            print("begin=\(Thread.current)")
            queue.sync {
                Thread.sleep(forTimeInterval: 1)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 主队列 + 1")
            }
            queue.sync {
                Thread.sleep(forTimeInterval: 3)
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "同步 + 主队列 + 3")
            }
            print("end===\(Thread.current)")
            CLToast.cl_show(msg: "完成")
            break
        case .AsyncMain: // 异步 + 主队列
            let queue = DispatchQueue.main
            print("begin=\(Thread.current)")
            queue.async {
                Thread.sleep(forTimeInterval: 5)
                print("1=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 主队列 + 5")
            }
            queue.async {
                Thread.sleep(forTimeInterval: 1)
                print("3=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 主队列 + 1")
            }
            queue.async {
                Thread.sleep(forTimeInterval: 3)
                print("4=====\(Thread.current)")
                CLToast.cl_show(msg: "异步 + 主队列 + 3")
            }
            print("end===\(Thread.current)")
            CLToast.cl_show(msg: "完成")
            break
        }
    }
}

// MARK:- 线程通讯、 dispatch_group和notify、group.barrier
extension WGIOS_GCD_VC {
    // MARK:- 线程通讯
    func threadCommunication() {
        let queue = DispatchQueue.global()
        print("begin=\(Thread.current)")
        queue.async {
            Thread.sleep(forTimeInterval: 5)
            print("1=====\(Thread.current)")
            CLToast.cl_show(msg: "线程通讯 + 1")
            DispatchQueue.main.async {
                print("2=====\(Thread.current)")
                CLToast.cl_show(msg: "线程通讯 + 2")
            }
        }
        print("end===\(Thread.current)")
    }
    // MARK:- 线程组
    func dispatchGroup() {
        let queue = DispatchQueue(label: "并行队列", attributes: .concurrent)
        let group = DispatchGroup.init()
        print("begin=\(Thread.current)")
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("1=====\(Thread.current)")
            CLToast.cl_show(msg: "线程组 + 1")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("2=====\(Thread.current)")
            CLToast.cl_show(msg: "线程组 + 2")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("3=====\(Thread.current)")
            CLToast.cl_show(msg: "线程组 + 3")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("4=====\(Thread.current)")
            CLToast.cl_show(msg: "线程组 + 4")
        }
        group.notify(queue: DispatchQueue.main) {
            print("notify\(Thread.current)")
        }
        print("end===\(Thread.current)")
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("5=====\(Thread.current)")
            CLToast.cl_show(msg: "线程组 + 5")
        }

    }
    // MARK:- group.barrier 屏障
    func queueBarrier() {
        let queue = DispatchQueue(label: "并行队列", attributes: .concurrent)
        let group = DispatchGroup.init()
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 2)
            print("1=====\(Thread.current)")
            CLToast.cl_show(msg: "屏障 + 1")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 2)
            print("2=====\(Thread.current)")
            CLToast.cl_show(msg: "屏障 + 2")
        }
        queue.async(group: group, qos: .default, flags: .barrier) {
            Thread.sleep(forTimeInterval: 2)
            print("3=====\(Thread.current)")
            CLToast.cl_show(msg: "屏障开始")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 2)
            print("4=====\(Thread.current)")
            CLToast.cl_show(msg: "屏障 + 4")
        }
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 2)
            print("5=====\(Thread.current)")
            CLToast.cl_show(msg: "屏障 + 5")
        }
    }
}

// MARK: - 设置dispatch_after、dispatch_group_wait、dispatch_group_enter、dispatch_group_leave、
extension WGIOS_GCD_VC {
    // MARK:- 延迟执行
    func dispatch_after() {
        let queue = DispatchQueue.global()
        queue.asyncAfter(deadline: DispatchTime.now() + 3) {
            print("5=====\(Thread.current)")
            CLToast.cl_show(msg: "延迟3秒执行")
        }
    }
    //dispatch_group_wait 阻塞当前线程，暂停当前线程。wait后面所有代码都不执行。
    func dispatch_group_wait() {
        let queue = DispatchQueue(label: "test",attributes: .concurrent)
        let group = DispatchGroup()
        print("begin=\(Thread.current)")
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("1=====\(Thread.current)")
            CLToast.cl_show(msg: "wait + 1")
        }
        
        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("2=====\(Thread.current)")
            CLToast.cl_show(msg: "wait + 2")
        }
        
        group.wait()

        queue.async(group: group, qos: .default, flags: .inheritQoS) {
            Thread.sleep(forTimeInterval: 3)
            print("5=====\(Thread.current)")
            CLToast.cl_show(msg: "wait + 3")
        }

        group.notify(queue: DispatchQueue.main) {
            print("notify\(Thread.current)")
            CLToast.cl_show(msg: "wait + notify")
        }
        print("end===\(Thread.current)")
    }
    //dispatch_group_enter_leave 未执行任务+1， group.leave() 未执行任务-1, 未执行任务=0，才会解除阻塞，继续执行后续代码。
    func dispatch_group_enter_leave() {
        let queue = DispatchQueue(label: "test", attributes: .concurrent)
        let group = DispatchGroup()
        print("begin=\(Thread.current)")
        group.enter()
        queue.async {
            Thread.sleep(forTimeInterval: 3)
            print("1=====\(Thread.current)")
            group.leave()
            CLToast.cl_show(msg: "leave + 1")
        }

        group.enter()
        queue.async {
            Thread.sleep(forTimeInterval: 3)
            print("2=====\(Thread.current)")
            group.leave()
            CLToast.cl_show(msg: "leave + 2")
        }

        group.enter()
        queue.async {
            Thread.sleep(forTimeInterval: 3)
            print("3=====\(Thread.current)")
            group.leave()
            CLToast.cl_show(msg: "leave + 3")
        }
        
        group.notify(queue: DispatchQueue.main) {
            print("notify\(Thread.current)")
        }
        print("end===\(Thread.current)")
    }

}

// MARK: - DispatchSemaphore线程锁、和线程加锁
extension WGIOS_GCD_VC {
    
    // MARK: - DispatchSemaphore线程锁
    func dispatch_semaphore() {
        let queue = DispatchQueue.global()
        //创建一个 Semaphore 并初始化信号的总量
        let semaphore = DispatchSemaphore(value: 0)
        print("begin====\(Thread.current)")
        queue.async {
            Thread.sleep(forTimeInterval: 5)
            print("signal===\(Thread.current)")
            //发送一个信号，让信号总量加 1
            semaphore.signal()
            CLToast.cl_show(msg: "dispatch_semaphore + signal")
        }
        //可以使总信号量减 1，信号总量小于 0 时就会一直等待（阻塞所在线程），否则就可以正常执行。
        semaphore.wait()
        print("end======\(Thread.current)")
    }
    
    // MARK: - 线程锁实例
    func dispatch_semaphore_money(flag:Bool) {
        let queueOne = DispatchQueue(label: "queueOne")
        let queueTwo = DispatchQueue(label: "queueTwo")
        let queueThree = DispatchQueue(label: "queueThree")
        queueOne.async {
            if flag {
                self.takeMoney()
            } else {
                self.notTakeMoney()
            }
        }
        queueTwo.async {
            if flag {
                self.takeMoney()
            } else {
                self.notTakeMoney()
            }
        }
        queueThree.async {
            if flag {
                self.takeMoney()
            } else {
                self.notTakeMoney()
            }
        }
    }
    //加锁
    func takeMoney() {
        while (1 != 0) {
            dispatchSemaphore.wait()
            if money > 0 {
                money = money - 1
                print("money==\(String(describing: money))==\(Thread.current)")
                CLToast.cl_show(msg: "money==\(String(describing: money))==\(Thread.current)")
            } else {
                print("no money====\(Thread.current)")
                dispatchSemaphore.signal()
                CLToast.cl_show(msg: "no money====\(Thread.current)")
                break
            }
            dispatchSemaphore.signal()
        }
    }
    //不加锁
    func notTakeMoney() {
        while (1 != 0) {
            if money > 0 {
                money = money - 1
                print("money==\(String(describing: money))==\(Thread.current)")
                CLToast.cl_show(msg: "money==\(String(describing: money))==\(Thread.current)")
            } else {
                print("no money====\(Thread.current)")
                dispatchSemaphore.signal()
                CLToast.cl_show(msg: "no money====\(Thread.current)")
                break
            }
        }
    }
}
