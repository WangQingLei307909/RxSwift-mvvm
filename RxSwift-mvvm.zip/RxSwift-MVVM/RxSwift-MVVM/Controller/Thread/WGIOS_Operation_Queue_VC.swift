//
//  WGIOS_Operation_Queue_VC.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGIOS_Operation_Queue_VC: ViewController {

    @IBOutlet weak var tableView: UITableView!
    var dataSource   = NSArray()
    let cellIdentify = "WGIOSKnowViewCell"
    public var titleString = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
        setUpTableView()
        creatDataSource()
    }
    
    func setUpTableView() {
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
    func creatDataSource() {
        dataSource = ["串行队列的创建方法",
                      "并发队列的创建方法",
                      "主队列的获取方法"]
    }

}

extension WGIOS_Operation_Queue_VC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSource[indexPath.row] as! String)
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
