//
//  WGIOS_Runtime_VC.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/3.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
let cellIdentify = "WGIOSKnowViewCell"
class WGIOS_Runtime_VC: ViewController {
    
    @IBOutlet weak var tableView: UITableView!
    lazy var dataSoure:Array<String>  = {
        let dataSoure = ["Runtime添加属性（类似OC版本）","Runtime添加属性（Swift版本）","Runtime方法交换","Runtime方法获取类属性","Runtime方法获取类方法","Runtime获取类协议"]
        return dataSoure
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
    }
    
    func setUpTableView() {
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
}


extension WGIOS_Runtime_VC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSoure.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSoure[indexPath.row])
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let string = dataSoure[indexPath.row]
        switch indexPath.row {
        case 0:
            swiftSetAndGetForOC(string: string)
            break
        case 1:
            swiftSetAndGetForSwift(string: string)
            break
        case 2:
            initializeMethod(string: string)
            break
        case 3:
            getClassProperty(string: string)
            break
        case 4:
            getClassMethod(string: string)
            break
        case 5:
            getClassProtocol(string: string)
            break
        default:
            break
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
}

// MARK:- // MARK:- Runtime添加属性
private var newOCPropertyKey = "OC版本默认初始值"
extension WGIOS_Runtime_VC {
    
    // MARK:- 类似OC版本
    func swiftSetAndGetForOC(string:String) {
        var newproperty : String {
            //新添加属性的get方法
            get {
                /*
                 第一个参数：关联的对象：给哪一个对象添加关联，这里就传哪一个对象
                 第二个参数：关联的key，通过这个key获取对应的值
                 */
                return objc_getAssociatedObject(self, &newOCPropertyKey) as! String
            }
            //新添加属性的set方法
            set(value) {
                /*
                  第一个参数：关联的对象：给哪一个对象添加关联，这里就传哪一个对象
                  第二个参数：关联的key，通过这个key设置（存储）对应的值，这里定义了一个newPropertyKey的key
                  第三个参数：关联的值，即通过key所关联的值，在get方法中获取的就是这个值
                  第四个参数：关联的方式
                 */
                objc_setAssociatedObject(self, &newOCPropertyKey, value, .OBJC_ASSOCIATION_RETAIN)
            }
        }
        newproperty = "测试一下"
        CLToast.cl_show(msg: string + "->" + newproperty)
    }
    

    // MARK:- Swift版本
    private struct AssociateKeys {
        static var swiftPropertyKey = "swiftPropertyKey" // 关联值的key
    }
    func swiftSetAndGetForSwift(string:String) {
        var newproperty : String {
            //新添加属性的get方法
            get {
                /*
                 第一个参数：关联的对象：给哪一个对象添加关联，这里就传哪一个对象
                 第二个参数：关联的key，通过这个key获取对应的值
                 */
                return objc_getAssociatedObject(self, &AssociateKeys.swiftPropertyKey) as! String
            }
            //新添加属性的set方法
            set(value) {
                /*
                  第一个参数：关联的对象：给哪一个对象添加关联，这里就传哪一个对象
                  第二个参数：关联的key，通过这个key设置（存储）对应的值，这里定义了一个newPropertyKey的key
                  第三个参数：关联的值，即通过key所关联的值，在get方法中获取的就是这个值
                  第四个参数：关联的方式
                 */
                objc_setAssociatedObject(self, &AssociateKeys.swiftPropertyKey, value, .OBJC_ASSOCIATION_RETAIN)
            }
        }
        newproperty = "测试一下"
        CLToast.cl_show(msg: string + "->" + newproperty)
    }
}

// MARK: - "Runtime方法交换"
extension WGIOS_Runtime_VC {
    
    func initializeMethod(string:String){
        let originalSelector = #selector(self.viewWillDisappear(_:))
        let swizzledSelector = #selector(self.new_viewWillDisappear(_:))
        let originalMethod = class_getInstanceMethod(self.classForCoder, originalSelector)
        let swizzledMethod = class_getInstanceMethod(self.classForCoder, swizzledSelector)
        let isAddMethod = class_addMethod(self.classForCoder, originalSelector, method_getImplementation(swizzledMethod!), method_getTypeEncoding(swizzledMethod!))
        if isAddMethod {
            class_replaceMethod(self.classForCoder, swizzledSelector, method_getImplementation(swizzledMethod!), method_getTypeEncoding(swizzledMethod!))
        } else {
            method_exchangeImplementations(originalMethod!, swizzledMethod!)
        }
        self.navigationController?.popViewController(animated: true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        print("原始方法")
    }
    
    @objc func new_viewWillDisappear(_ animated: Bool) {
        print("Runtime添加属性（Swift版本）交换后的方法")
        CLToast.cl_show(msg: "Runtime添加属性（Swift版本）交换后的方法")
    }
    
}

// MARK:- 获取当前类的属性、方法、协议
extension WGIOS_Runtime_VC {
    
    //获取属性
    func getClassProperty(string:String) {
        var count : UInt32 = 0
        let propertyList = class_copyIvarList(self.classForCoder, &count)
        for item in 0..<count {
            // 获取属性名的C（C语言的字符串）
            let propertyNameC = ivar_getName(propertyList![Int(item)])!
            let propertyName = String.init(utf8String: propertyNameC)
            let propertyTypeC = ivar_getTypeEncoding(propertyList![Int(item)])!
            let propertyType = String.init(utf8String: propertyTypeC)
            print(propertyName as Any,propertyType as Any)
        }
        free(propertyList)
        CLToast.cl_show(msg: string)
    }
    
    //获取方法
    func getClassMethod(string:String) {
        var count : UInt32 = 0
        let methodList = class_copyMethodList(self.classForCoder, &count)
        for item in 0..<count {
            let sel = method_getName((methodList?[Int(item)])!)
            let methodNameC = NSStringFromSelector(sel)
            print(methodNameC)
        }
        free(methodList)
        CLToast.cl_show(msg: string)
    }
    
    //获取协议
    func getClassProtocol(string:String) {
        var count : UInt32 = 0
        let protocollList = class_copyProtocolList(self.classForCoder, &count)
        for item in 0..<count {
            let protocols = protocol_getName((protocollList?[Int(item)])!)
            let protocolName = String.init(utf8String: protocols)
            print(protocolName as Any)
        }
        CLToast.cl_show(msg: string)
    }
    
}

