//
//  WGIOS_Runloop_VC.swift
//  WGNewsProject
//
//  Created by abox on 2021/3/4.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import CLToast
class WGIOS_Runloop_VC: ViewController {

    @IBOutlet weak var tableView: UITableView!
    var dataSource   = NSArray()
    let cellIdentify = "WGIOSKnowViewCell"
    public var titleString = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        darkMode()
        setUpTableView()
        creatDataSource()
    }
    
    func setUpTableView() {
        
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
    }
    
    func creatDataSource() {
        dataSource = ["runloop介绍",
                      "线程和runloop",
                      "默认情况下主线程的 RunLoop 原理",
                      "RunLoop 相关类",
                      "CFRunLoopRef",
                      "CFRunLoopModeRef",
                      "CFRunLoopTimerRef",
                      "CFRunLoopSourceRef",
                      "CFRunLoopObserverRef"]
    }

}

extension WGIOS_Runloop_VC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentify, for: indexPath) as! WGIOSKnowViewCell
        cell.setCellData(string: dataSource[indexPath.row] as! String)
        cell.accessoryType = .disclosureIndicator
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            runloopIntroduce()
        }
        if indexPath.row == 1 {
            threadAndRunloop()
        }
        if indexPath.row == 2 {
            mainThreadRunloop()
        }
        if indexPath.row == 3 {
            runloopRelatedClass()
        }
        if indexPath.row == 4 {
            runloopCFRunLoopRef()
        }
        if indexPath.row == 5 {
            cfRunLoopModeRef()
        }
        if indexPath.row == 6 {
            cfRunLoopTimerRef()
        }
        if indexPath.row == 7 {
            cfRunLoopSourceRef()
        }
        if indexPath.row == 8 {
            cfRunLoopObserverRef()
        }
    }
}

// MARK: - "runloop介绍" "线程和runloop" "默认情况下主线程的 RunLoop 原理" "RunLoop 相关类" "CFRunLoopRef", CFRunLoopModeRef 模式
extension WGIOS_Runloop_VC {
    
    // MARK: - runloop介绍
    func runloopIntroduce() {
        let introduce = "可以理解为字面意思：Run 表示运行，Loop 表示循环。结合在一起就是运行的循环的意思。哈哈，我更愿意翻译为『跑圈』。直观理解就像是不停的跑圈。\nRunLoop 实际上是一个对象，这个对象在循环中用来处理程序运行过程中出现的各种事件（比如说触摸事件、UI刷新事件、定时器事件、Selector事件），从而保持程序的持续运行。\nRunLoop 在没有事件处理的时候，会使线程进入睡眠模式，从而节省 CPU 资源，提高程序性能。"
        print(introduce)
        CLToast.cl_show(msg: introduce)
    }
    
    // MARK: - 线程和runloop
    func threadAndRunloop() {
        let string = "RunLoop 和线程是息息相关的，我们知道线程的作用是用来执行特定的一个或多个任务，在默认情况下，线程执行完之后就会退出，就不能再执行任务了。这时我们就需要采用一种方式来让线程能够不断地处理任务，并不退出。所以，我们就有了 RunLoop。\n 一条线程对应一个RunLoop对象，每条线程都有唯一一个与之对应的 RunLoop 对象。\n RunLoop 并不保证线程安全。我们只能在当前线程内部操作当前线程的 RunLoop 对象，而不能在当前线程内部去操作其他线程的 RunLoop 对象方法。\n RunLoop 对象在第一次获取 RunLoop 时创建，销毁则是在线程结束的时候。\n 主线程的 RunLoop 对象系统自动帮助我们创建好了，而子线程的 RunLoop对象需要我们主动创建和维护。"
        print(string)
        CLToast.cl_show(msg: string)
    }
    
    // MARK: - 默认情况下主线程的 RunLoop 原理
    func mainThreadRunloop() {
        
        /*
         //我们在启动一个iOS程序的时候，系统会调用创建项目时自动生成的 main.m 的文件。main.m文件如下所示：
         /**
          int main(int argc, char * argv[]) {
              @autoreleasepool {
                  return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
              }
          }
          */
         //其中 UIApplicationMain 函数内部帮我们开启了主线程的 RunLoop，UIApplicationMain 内部拥有一个无限循环的代码，只要程序不退出/崩溃，它就一直循环。上边的代码中主线程开启 RunLoop 的过程可以简单的理解为如下代码：
         /**
          int main(int argc, char * argv[]) {
              BOOL running = YES;
              do {
                  // 执行各种任务，处理各种事件
                  // ......
              } while (running);  // 判断是否需要退出

              return 0;
          }
          */
         //从上边可看出，程序一直在 do-while 循环中执行，所以 UIApplicationMain 函数一直没有返回，我们在运行程序之后程序不会马上退出，会保持持续运行状态
         */
        CLToast.cl_show(msg: "默认情况下主线程的 RunLoop 原理")
    }
    
    // MARK: - RunLoop 相关类
    func runloopRelatedClass() {
        /*
         下面我们来了解一下Core Foundation框架下关于 RunLoop 的 5 个类，只有弄懂这几个类的含义，我们才能深入了解 RunLoop 的运行机制。

         CFRunLoopRef：代表 RunLoop 的对象
         CFRunLoopModeRef：代表 RunLoop 的运行模式
         CFRunLoopSourceRef：就是 RunLoop 模型图中提到的输入源 / 事件源
         CFRunLoopTimerRef：就是 RunLoop 模型图中提到的定时源
         CFRunLoopObserverRef：观察者，能够监听 RunLoop 的状态改变
         */
        
        
        // 5 个类的相互关系：
        
        /*
         一个RunLoop对象（CFRunLoopRef）中包含若干个运行模式（CFRunLoopModeRef）。而每一个运行模式下又包含若干个输入源（CFRunLoopSourceRef）、定时源（CFRunLoopTimerRef）、观察者（CFRunLoopObserverRef）。
         每次 RunLoop 启动时，只能指定其中一个运行模式（CFRunLoopModeRef），这个运行模式（CFRunLoopModeRef）被称作当前运行模式（CurrentMode）。
         如果需要切换运行模式（CFRunLoopModeRef），只能退出当前 Loop，再重新指定一个运行模式（CFRunLoopModeRef）进入。
         这样做主要是为了分隔开不同组的输入源（CFRunLoopSourceRef）、定时源（CFRunLoopTimerRef）、观察者（CFRunLoopObserverRef），让其互不影响 。
         */
        CLToast.cl_show(msg: "RunLoop 相关类")
    }
    
    // MARK: - CFRunLoopRef 类
    func runloopCFRunLoopRef() {
        
        /**
         
         CFRunLoopRef 是 Core Foundation 框架下 RunLoop 对象类。我们可通过以下方式来获取 RunLoop 对象：

         Core Foundation
         CFRunLoopGetCurrent() // 获得当前线程的 RunLoop 对象
         CFRunLoopGetMain() // 获得主线程的 RunLoop 对象
         当然，在Foundation 框架下获取 RunLoop 对象类的方法如下：

         Foundation
         RunLoop.current  // 获得当前线程的 RunLoop 对象
         RunLoop.main  // 获得主线程的 RunLoop 对象
         
         */
        CLToast.cl_show(msg: "CFRunLoopRef 类")
    }
    
    // MARK:- CFRunLoopModeRef 模式
    func cfRunLoopModeRef() {
        /**
         
         系统默认定义了多种运行模式（CFRunLoopModeRef），如下：

         kCFRunLoopDefaultMode：App的默认运行模式，通常主线程是在这个运行模式下运行
         UITrackingRunLoopMode：跟踪用户交互事件（用于 ScrollView 追踪触摸滑动，保证界面滑动时不受其他Mode影响）
         UIInitializationRunLoopMode：在刚启动App时第进入的第一个 Mode，启动完成后就不再使用
         GSEventReceiveRunLoopMode：接受系统内部事件，通常用不到
         kCFRunLoopCommonModes：伪模式，不是一种真正的运行模式（后边会用到）
         其中kCFRunLoopDefaultMode、UITrackingRunLoopMode、kCFRunLoopCommonModes是我们开发中需要用到的模式，具体使用方法我们在 2.3 CFRunLoopTimerRef 中结合CFRunLoopTimerRef来演示说明。
         
         */
        CLToast.cl_show(msg: "CFRunLoopModeRef 模式")
    }

}

extension WGIOS_Runloop_VC {
    func cfRunLoopTimerRef() {
        /**
         
         CFRunLoopTimerRef是定时源（RunLoop模型图中提到过），理解为基于时间的触发器，基本上就是NSTimer（哈哈，这个理解就简单了吧）。

         下面我们来演示下CFRunLoopModeRef和CFRunLoopTimerRef结合的使用用法，从而加深理解。

         */
        //在此我们创建一个UITextView。添加到View上，接下开我们创建定时器
        let timer = Timer.init(timeInterval: 2, target: self, selector: #selector(run), userInfo: nil, repeats: true)
        timer.fireDate = NSDate.distantPast
        // 将定时器添加到当前RunLoop的NSDefaultRunLoopMode下
        /*
         这里模式就会有很大区别，首先我们讲一下NSDefaultRunLoopMode模式
         这个是Runloop默认模式，当我们运行此程序，默认此模式，定时器会进入执行状态，但是发现我们对页面进行操作（滑动UITextView）就不会再执行，但是不进行操作就有再次执行
         原因：当我们不做任何操作，Runloop处于NSDefaultRunLoopMode默认模式，当我们进行滑动或者其他错做，就会进入UITrackingRunLoopMode，而我们写的代码是添加到NSDefaultRunLoopMode上，UITrackingRunLoopMode上没有定时器所以无法打印
         */
        RunLoop.current.add(timer, forMode: .default)
        
        // 将定时器添加到当前RunLoop的UITrackingRunLoopMode下，我们发现定时器直接不运行了，当时当我们滑动UITextView定时器又在开始执行，结束滑动定时有再次停止
        /*
         UITrackingRunLoopMode,可以理解为跟踪模式，当我们
         */
        RunLoop.current.add(timer, forMode: .tracking)
        // 很明显这两种模式都不是我们逍遥的结果，我们想要的是在当前页面下，这个定时器一直保持运行状态，那我们要如何处理呢
        /*
         NSRunLoopCommonModes（伪模式、或者公共模式） 就可以合理的解决这个问题，从字面意思我们就可以看出这个模式效果，只要进入此页面就会一执行，除非销毁timer和Runloop
         */
        RunLoop.current.add(timer, forMode: .common)
//        RunLoop.current.add(timer, forMode: .default)
//        RunLoop.current.add(timer, forMode: .tracking)
    }
    
    @objc func run() {
        print("runloop执行了～")
    }
    
    // MARK: - CFRunLoopSourceRef

    func cfRunLoopSourceRef() {
        /*
         //其实这个通俗来讲就是执行的事件，我们创建一个button，我们通过断点的方式就可以发现action就是CFRunLoopSourceRef执行的事件
         //效果连接🔗https://www.jianshu.com/p/d260d18dd551
         */
        /*
        CFRunLoopSourceRef是事件源（RunLoop模型图中提到过），CFRunLoopSourceRef有两种分类方法。

        第一种按照官方文档来分类（就像RunLoop模型图中那样）：
        Port-Based Sources（基于端口）
        Custom Input Sources（自定义）
        Cocoa Perform Selector Sources
        第二种按照函数调用栈来分类：
        Source0 ：非基于Port
        Source1：基于Port，通过内核和其他线程通信，接收、分发系统事件
        这两种分类方式其实没有区别，只不过第一种是通过官方理论来分类，第二种是在实际应用中通过调用函数来分类
        */
        let button = UIButton.init(frame: CGRect.init(x: 50, y: 200, width: 100, height: 100))
        button.backgroundColor = .black
        self.view.addSubview(button)
        button.addTarget(self, action: #selector(action(button:)), for: .touchUpInside)
    }
    @objc func action(button:UIButton) {
        
    }
    
    // MARK: - CFRunLoopObserverRef 观察者
    func cfRunLoopObserverRef() {
        /*
        CFRunLoopObserverRef是观察者，用来监听RunLoop的状态改变

        CFRunLoopObserverRef可以监听的状态改变有以下几种：
        typedef CF_OPTIONS(CFOptionFlags, CFRunLoopActivity) {
            kCFRunLoopEntry = (1UL << 0),               // 即将进入Loop：1
            kCFRunLoopBeforeTimers = (1UL << 1),        // 即将处理Timer：2
            kCFRunLoopBeforeSources = (1UL << 2),       // 即将处理Source：4
            kCFRunLoopBeforeWaiting = (1UL << 5),       // 即将进入休眠：32
            kCFRunLoopAfterWaiting = (1UL << 6),        // 即将从休眠中唤醒：64
            kCFRunLoopExit = (1UL << 7),                // 即将从Loop中退出：128
            kCFRunLoopAllActivities = 0x0FFFFFFFU       // 监听全部状态改变
        };
        */
        //举个例子，我们观察当前CFRunLoopActivity活跃变化
        // 创建观察者
        let observer = CFRunLoopObserverCreateWithHandler((CFAllocatorGetDefault()! as! CFAllocator),CFOptionFlags.init() , true, 0) { (observer, activity) in
            print("监听到RunLoop发生改变---%ld",activity)
        }
        // 添加观察者到当前RunLoop中
        CFRunLoopAddObserver(CFRunLoopGetCurrent(), observer,CFRunLoopMode.defaultMode)
    }
    
}
