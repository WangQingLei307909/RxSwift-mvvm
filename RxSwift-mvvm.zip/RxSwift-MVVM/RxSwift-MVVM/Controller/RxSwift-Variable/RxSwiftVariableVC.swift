//
//  RxSwiftVariableVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/24.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftVariableVC: ViewController {

    @IBOutlet weak var VariableButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        /*
         Variable 其实就是对 BehaviorSubject 的封装，所以它也必须要通过一个默认的初始值进行创建。
         Variable 具有 BehaviorSubject 的功能，能够向它的订阅者发出上一个 event 以及之后新创建的 event。
         不同的是，Variable 还会把当前发出的值保存为自己的状态。同时它会在销毁时自动发送 .complete的 event，不需要也不能手动给 Variables 发送 completed或者 error 事件来结束它。
         简单地说就是 Variable 有一个 value 属性，我们改变这个 value 属性的值就相当于调用一般 Subjects 的 onNext() 方法，而这个最新的 onNext() 的值就被保存在 value 属性里了，直到我们再次修改它。
         */
        
        
        VariableButton.rx.tap.subscribe(onNext: { [weak self] in
            self!.variableAction()
        }).disposed(by: disposeBag)
        
        
        
    }

    func variableAction() {
        let variable = Variable("111")
        
        variable.value = "222"
        
        variable.asObservable().subscribe { (event) in
             print("第一次订阅", event)
        }.disposed(by: disposeBag)
        
        variable.value = "333"
        
        variable.asObservable().subscribe { (event) in
            print("第二次订阅", event)
        }.disposed(by: disposeBag)
        
        variable.value = "444"
        /*
         通过打印结果，我们不难看出，Variable有三个特点
         1、就是创建的时候需要初始值，但是初始值并不会走订阅的方法
         2、只会保留最新的Value赋值，当value变化时会将旧的值进行覆盖
         3、当发送消息的时候，只要涉及到订阅的地方都会走一遍订阅
         */
    }

}
