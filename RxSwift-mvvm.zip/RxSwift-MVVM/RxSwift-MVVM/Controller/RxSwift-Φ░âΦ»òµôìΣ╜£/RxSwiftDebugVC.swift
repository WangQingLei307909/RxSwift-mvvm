//
//  RxSwiftDebugVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/25.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftDebugVC: ViewController {

    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        button1.rx.tap.subscribe(onNext: {[weak self] in
            self!.debug()
        }).disposed(by: disposeBag)
        
        button2.rx.tap.subscribe(onNext: {[weak self] in
            self!.ResourcesTotal()
        }).disposed(by: disposeBag)
        
    }

    func debug() {
        // 我们可以将 debug 调试操作符添加到一个链式步骤当中，这样系统就能将所有的订阅者、事件、和处理等详细信息打印出来，方便我们开发调试。
        // debug() 方法还可以传入标记参数，这样当项目中存在多个 debug 时可以很方便地区分出来。
        Observable.of("2","3","4","5").startWith("1").debug("调试").subscribe(onNext: {
            print($0)
        }).disposed(by: disposeBag)
    }
    
    func ResourcesTotal() {
        // RxSwift.Resources.total
        // 通过将 RxSwift.Resources.total 打印出来，我们可以查看当前 RxSwift 申请的所有资源数量。这个在检查内存泄露的时候非常有用。
        print(RxSwift.Resources.total)
        Observable.of("BBB","CCC","DDD","EEE").startWith("AAA").subscribe(onNext: {
            print($0)
            }).disposed(by: disposeBag)
    }
    
}
