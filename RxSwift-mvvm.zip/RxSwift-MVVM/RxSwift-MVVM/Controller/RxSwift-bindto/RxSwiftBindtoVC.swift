//
//  RxSwiftBindtoVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/25.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
class RxSwiftBindtoVC: ViewController {

    @IBOutlet weak var switchs: UISwitch!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        
        /// 创建一个观察者
        let observer: AnyObserver<String> = AnyObserver { [weak self] event in
            switch event {
            case .next( let text ) :
                self!.label.text = text
                break
            default:
                break
            }
        }
        
        //        Binder 用于特定场景
        //        1、不会处理错误事件
        //        2、确保绑定都是在给定的 Scheduler 上执行 默认MainScheduler.instance
//        let binder: Binder<String> = Binder(label) { lab , text in
//            lab.text = text
//        }
        
        let observable = Observable<Int>.interval(1, scheduler: MainScheduler.instance)
        observable.map({
            "当前定时器索引：\($0)"
            }).bind(to: label.rx.text).disposed(by: disposeBag)
        
        
        //将switch的打开关闭时间绑定到button的isEnable上
        switchs.rx.isOn.bind(to: button.rx.isEnabled).disposed(by: disposeBag)
 
        
    }


}
