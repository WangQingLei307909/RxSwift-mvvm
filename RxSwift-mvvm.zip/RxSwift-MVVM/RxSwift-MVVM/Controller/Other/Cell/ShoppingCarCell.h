//
//  ShoppingCarCell.h
//  AmzingBox
//
//  Created by abox on 2020/8/10.
//  Copyright © 2020 abox. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HSFolderCell.h"
NS_ASSUME_NONNULL_BEGIN

@interface ShoppingCarCell : HSFolderCell
@property (copy, nonatomic) void(^SelectBlock)(NSInteger indexPathRow);
@property (copy, nonatomic) NSString *nameString;
@end

NS_ASSUME_NONNULL_END
