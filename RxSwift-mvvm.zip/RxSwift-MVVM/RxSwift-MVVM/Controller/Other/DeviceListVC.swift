//
//  DeviceListVC.swift
//  AmzingBox
//
//  Created by abox on 2020/7/16.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit
import CLToast
class DeviceListVC: ViewController,UITableViewDelegate,UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemHeight.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ShoppingCarCell") as! ShoppingCarCell
        cell.selectBlock = { indexPathRow in
            CLToast.cl_show(msg: "折叠效果")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if !cell.isMember(of: ShoppingCarCell.self) {
            return;
        }
        let newCell = cell as! ShoppingCarCell
        cell.backgroundColor = UIColor.clear
        if itemHeight[indexPath.row] as! String == closeHeight {
            newCell.unfold(false, animated: false, completion: nil)
        } else {
            newCell.unfold(true, animated: false, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath) as! ShoppingCarCell
        var duration:TimeInterval = 0.0
        if itemHeight[indexPath.row] as! String == closeHeight {
            itemHeight[indexPath.row] = openHeight
            cell.unfold(true, animated: true, completion: nil)
            duration = 0.5
        } else {
            itemHeight[indexPath.row] = closeHeight
            cell.unfold(false, animated: true, completion: nil)
            duration = 1.1
        }
        UIView.animate(withDuration: duration, delay: 0, options: UIView.AnimationOptions.curveEaseOut, animations: {
            tableView.beginUpdates()
            tableView.endUpdates()
        }) { (flag) in }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return itemHeight[indexPath.row] as! String == closeHeight ? 181 : 496
    }
    
    var itemHeight = NSMutableArray()
    let closeHeight = "181"
    let openHeight = "496"
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCommonData()
    }
    
    func setUpCommonData() {
        tableView.register(ShoppingCarCell.self, forCellReuseIdentifier: "ShoppingCarCell")
        for _ in 0..<15 {
            itemHeight.add(closeHeight)
        }
        tableView.reloadData()
    }
}
