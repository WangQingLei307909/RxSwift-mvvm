//
//  CombinationAniVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/20.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class CombinationAniVC: ViewController,DCPathButtonDelegate {

    
    var type = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = type == 0 ? "home键" : type == 1 ? "钉钉" : "点赞"
        loadAnimationWithType()
    }
    
    // MARK: - 创建动画
    func loadAnimationWithType() {
        switch type {
        case 0://home键
            makeAPathAnimation()
            break
        case 1://叮叮
            makeDingdingAnimation()
            break
        case 2://点赞
            makeDianzanAnimation()
            break
        default: break
        }
    }
    // MARK: - home键动画
    func makeAPathAnimation() {
        let dcPathButton = DCPathButton.init(center: UIImage.init(named: "chooser-button-tab"), hilightedImage: UIImage.init(named: "chooser-button-tab-highlighted"))
        dcPathButton?.delegate = self as DCPathButtonDelegate
        
        let music = DCPathItemButton.init(image: UIImage.init(named: "chooser-moment-icon-music"), highlightedImage: UIImage.init(named: "chooser-moment-icon-music-highlighted"), backgroundImage: UIImage.init(named: "chooser-moment-button"), backgroundHighlightedImage: UIImage.init(named: "chooser-moment-button-highlighted"))
        
        let location = DCPathItemButton.init(image: UIImage.init(named: "chooser-moment-icon-place"), highlightedImage: UIImage.init(named: "chooser-moment-icon-place-highlighted"), backgroundImage: UIImage.init(named: "chooser-moment-button"), backgroundHighlightedImage: UIImage.init(named: "chooser-moment-button-highlighted"))
        
        let camera = DCPathItemButton.init(image: UIImage.init(named: "chooser-moment-icon-camera"), highlightedImage: UIImage.init(named: "chooser-moment-icon-camera-highlighted"), backgroundImage: UIImage.init(named: "chooser-moment-button"), backgroundHighlightedImage: UIImage.init(named: "chooser-moment-button-highlighted"))
        
        let thought = DCPathItemButton.init(image: UIImage.init(named: "chooser-moment-icon-thought"), highlightedImage: UIImage.init(named: "chooser-moment-icon-thought-highlighted"), backgroundImage: UIImage.init(named: "chooser-moment-button"), backgroundHighlightedImage: UIImage.init(named: "chooser-moment-button-highlighted"))
        
        let sleep = DCPathItemButton.init(image: UIImage.init(named: "chooser-moment-icon-sleep"), highlightedImage: UIImage.init(named: "chooser-moment-icon-sleep-highlighted"), backgroundImage: UIImage.init(named: "chooser-moment-button"), backgroundHighlightedImage: UIImage.init(named: "chooser-moment-button-highlighted"))
        dcPathButton?.addPathItems([music!,location!,camera!,thought!,sleep!])
        self.view.addSubview(dcPathButton!)
    }
    
    /// 点击的第几个按钮
    /// - Parameter index: 下标
    func itemButtonTapped(at index: UInt) {
        
    }
    
    // MARK: - 叮叮列表动画
    func makeDingdingAnimation() {
        let upMenuView = DWBubbleMenuButton.init(frame: CGRect.init(x: kScreenWidth - 60, y: kScreenHeight - 60, width: 40, height: 40), expansionDirection: ExpansionDirection.DirectionUp)
        upMenuView?.homeButtonView = createHomeButtonView()
        upMenuView?.addButtons(createDemoButtonArray() as? [Any])
        self.view.addSubview(upMenuView!)
    }
    
    /// 创建点击提示按钮
    func createHomeButtonView() -> UILabel {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 40, height: 40))
        label.text = "Tap"
        label.textColor = UIColor.white;
        label.textAlignment = NSTextAlignment.center;
        label.layer.cornerRadius = label.frame.size.height / 2;
        label.backgroundColor = UIColor.init(displayP3Red: 0, green: 0, blue: 0, alpha: 0.5);
        label.clipsToBounds = true;
        return label
    }
    
    /// 创建叮叮列表按钮
    func createDemoButtonArray() -> NSMutableArray {
        let buttonsMutable = NSMutableArray()
        let i = 0
        let array = ["A", "B", "C", "D", "E", "F"]
        for title:String in array {
            let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 30, height: 30))
            button.setTitle(title, for: UIControl.State.normal)
            button.setTitleColor(UIColor.white, for: UIControl.State.normal)
            button.layer.cornerRadius = 15
            button.backgroundColor = UIColor.init(displayP3Red: 0, green: 0, blue: 0, alpha: 0.4)
            button.clipsToBounds = true
            button.tag = i + 1
            button.addTarget(self, action: #selector(dwBtnClick), for: UIControl.Event.touchUpInside)
            buttonsMutable.add(button)
        }
        return buttonsMutable;
    }
    
    /// 点击叮叮列表按钮
    /// - Parameter button: 第几个按钮
    @objc func dwBtnClick(button:UIButton) {
        
    }
    
    // MARK: - 点赞键动画
    func makeDianzanAnimation(){
        let btn = MCFireworksButton.init(frame: CGRect.init(x: kScreenWidth/2 - 25, y: kScreenHeight/2-25, width: 50, height: 50))
        btn.particleImage = UIImage.init(named: "Sparkle")
        btn.particleScale = 0.05
        btn.particleScaleRange = 0.02
        btn.isSelected = false
        btn.setImage(UIImage.init(named: "Like"), for: UIControl.State.normal)
        btn.addTarget(self, action: #selector(handleButtonPress), for: UIControl.Event.touchUpInside)
        self.view.addSubview(btn)
    }
    
    /// 点击或者取消按钮
    /// - Parameter btn: btn description
    @objc func handleButtonPress(btn:MCFireworksButton){
        btn.isSelected = !btn.isSelected;
        if (btn.isSelected){
            btn.popOutside(withDuration: 0.5)
            btn.setImage(UIImage.init(named: "Like-Blue"), for: UIControl.State.normal)
            btn.animate()
        }else{
            btn.popInside(withDuration: 0.4)
            btn.setImage(UIImage.init(named: "Like"), for: UIControl.State.normal)
        }
    }
    
    
    
}
