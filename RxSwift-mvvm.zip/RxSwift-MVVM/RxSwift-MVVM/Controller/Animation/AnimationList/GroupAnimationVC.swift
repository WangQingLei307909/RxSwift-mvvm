//
//  GroupAnimationVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/21.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class GroupAnimationVC: ViewController {

    var type = Int()
    var babyView = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = type == 0 ? "关键帧" : type == 1 ? "路径" : "抖动"
        creatBabyView()
        creatAnimationm()
    }
    
    
    /// 创建动画View
    func creatBabyView() {
        babyView = UIView.init(frame: CGRect.init(x: (kScreenWidth - 100)/2, y: kScreenHeight/2 - 100, width: 100, height: 100))
        babyView.backgroundColor = UIColor.red
        self.view.addSubview(babyView)
    }
    
    // MARK: - 创建动画View
    func creatAnimationm(){
        switch (type) {
            case 0:
                makeKeyFrameAnimation()
                break
            case 1:
                makeGoOnAnimation()
                break
            default:
                break
        }
    }

    //关键帧动画
    func makeKeyFrameAnimation(){
        let animation = CAKeyframeAnimation.init(keyPath: "position")
        let value_0 = NSValue.init(cgPoint: CGPoint.init(x: 50, y: kScreenHeight/2 - 50))
        let value_1 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth/3, y: kScreenHeight/2 - 50))
        let value_2 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth/3, y: kScreenHeight/2 + 50))
        let value_3 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth*2/3, y: kScreenHeight/2 + 50))
        let value_4 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth*2/3, y: kScreenHeight/2 - 50))
        let value_5 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth-50, y: kScreenHeight/2 - 50))
        animation.values = [value_0,value_1,value_2,value_3,value_4,value_5]
        
        let scaleAni = CABasicAnimation.init(keyPath: "transform.scale");
        scaleAni.fromValue = NSNumber.init(floatLiteral: 0.8);
        scaleAni.toValue = NSNumber.init(floatLiteral: 2);
          
        let rotateAni = CABasicAnimation.init(keyPath: "transform.rotation");
        rotateAni.toValue = NSNumber.init(floatLiteral: .pi*4);
          
        let groupAni = CAAnimationGroup.init();
        groupAni.animations = [animation,scaleAni,rotateAni];
        groupAni.duration = 4.0;
        babyView.layer.add(groupAni, forKey: "groupAnimation")
    }

    //路径
    func makeGoOnAnimation(){
        //定义一个动画开始的时间
        let currentTime = CACurrentMediaTime();
        
        let positionAni = CABasicAnimation.init(keyPath: "position");
        positionAni.fromValue = NSValue.init(cgPoint: CGPoint.init(x: 50, y: kScreenHeight/2))
        positionAni.toValue = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth/2, y: kScreenHeight/2));
        positionAni.duration = 1.0;
        positionAni.fillMode = CAMediaTimingFillMode.forwards
        positionAni.isRemovedOnCompletion = false;
        positionAni.beginTime = currentTime;
        babyView.layer.add(positionAni, forKey: "positionAnimation")
        
        let scaleAnimation = CABasicAnimation.init(keyPath: "transform.scale")
        scaleAnimation.fromValue = NSNumber.init(floatLiteral: 0.8)
        scaleAnimation.toValue = NSNumber.init(floatLiteral: 2)
        scaleAnimation.duration = 1.0;
        scaleAnimation.fillMode = CAMediaTimingFillMode.forwards
        scaleAnimation.isRemovedOnCompletion = false;
        scaleAnimation.beginTime = currentTime + 1.0;
        babyView.layer.add(scaleAnimation, forKey: "scaleAnimation")
        
        let rotateAnimation = CABasicAnimation.init(keyPath: "transform.rotation");
        rotateAnimation.toValue = NSNumber.init(floatLiteral: .pi*4);
        rotateAnimation.duration = 1.0;
        scaleAnimation.fillMode = CAMediaTimingFillMode.forwards
        rotateAnimation.isRemovedOnCompletion = false;
        rotateAnimation.beginTime = currentTime + 2.0;
        babyView.layer.add(rotateAnimation, forKey: "rotateAnimation")
    }

}
