//
//  BaseAnimationVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/21.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class BaseAnimationVC: ViewController {

    var type = Int()
    var babyView = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = type == 0 ? "位移" : type == 1 ? "透明度" :  type == 2 ? "缩放" :   type == 3 ? "旋转" : "背景色"
        creatBabyView()
        creatAnimation()
    }

    func creatBabyView() {
        babyView = UIView.init(frame: CGRect.init(x: (kScreenWidth - 100)/2, y: kScreenHeight/2 - 100, width: 100, height: 100))
        babyView.backgroundColor = UIColor.red
        self.view.addSubview(babyView)
    }
    
    func creatAnimation(){
        switch type {
        case 0:
            makePositionAnimation()
            break
        case 1:
            makeOpacityAnimation()
            break
        case 2:
            makeScaleAnimation()
            break
        case 3:
            makeRotateAnimation()
            break
        case 4:
            makeBackgroundAnimation()
            break
        default:
            break
        }
    }
    
    //位移
    func makePositionAnimation() {
        let animation = CABasicAnimation.init(keyPath: "position")
        animation.fromValue = NSValue.init(cgPoint: CGPoint.init(x: 50, y: kScreenHeight/2 - 75))
        animation.toValue = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth - 50, y: kScreenHeight/2 - 75))
        animation.duration = 1.0;
        //animation.fillMode = kCAFillModeForwards;
        //animation.removedOnCompletion = NO;
        babyView.layer.add(animation, forKey: "positionAnimation")
    }

    //透明度
    func makeOpacityAnimation() {
        let animation = CABasicAnimation.init(keyPath: "opacity")
        animation.fromValue = NSNumber.init(floatLiteral: 1)
        animation.toValue = NSNumber.init(floatLiteral: 0.5)
        animation.duration = 1.0;
        babyView.layer.add(animation, forKey: "opacityAnimation")
    }

    //缩放
    func makeScaleAnimation(){
        let animation = CABasicAnimation.init(keyPath: "transform.scale")
        animation.toValue = NSNumber.init(floatLiteral: 2);
        animation.duration = 1.0;
        babyView.layer.add(animation, forKey: "scaleAnimation")
    }

    //旋转
    func makeRotateAnimation(){
        let animation = CABasicAnimation.init(keyPath: "transform.rotation.z")
        animation.toValue = NSNumber.init(floatLiteral: .pi);
        animation.duration = 1.0;
        babyView.layer.add(animation, forKey: "rotateAnimation")
    }

    //背景色变化
    func makeBackgroundAnimation(){
        let animation = CABasicAnimation.init(keyPath: "backgroundColor")
        animation.toValue = UIColor.green.cgColor;
        animation.duration = 1.0;
        babyView.layer.add(animation, forKey: "backgroundAnimation")
    }

}
