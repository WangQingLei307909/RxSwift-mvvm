//
//  AnimationLisVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/4/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import RxDataSources
class AnimationLisVC: ViewController {

    @IBOutlet weak var tableView: UITableView!
    
    let disposeBag = DisposeBag()

    let items = Observable.just([SectionModel(model: "基础动画", items: ["位移","透明度","缩放","旋转","背景色"]),
                                 SectionModel(model: "关闭帧动", items: ["关键帧","路径","抖动"]),
                                 SectionModel(model: "组动画", items: ["同时","连续"]),
                                 SectionModel(model: "过度动画", items: ["fade","moveIn","push","reveal","cube","suck","oglFile","ripple","curl","unCurl","caOpen","caClose"]),
                                 SectionModel(model: "组合动画", items: ["path","钉钉","点赞"])])
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let dataSoucre = RxTableViewSectionedReloadDataSource<SectionModel<String,String>>(configureCell:{ (dataSouece, tv, indexPath, element) -> UITableViewCell in
            let cell = tv.dequeueReusableCell(withIdentifier: "WGIOSKnowViewCell", for: indexPath) as! WGIOSKnowViewCell
            cell.titleLabel.textColor = .randomColor()
            cell.titleLabel.text = element
            return cell
        }, titleForHeaderInSection: { data ,sectionIndex in
            return data[sectionIndex].model
        })
        //点击选择
        tableView.rx.itemSelected.subscribe(onNext: { ( indexPath ) in
            if  indexPath.section == 0 {
                let combination = BaseAnimationVC()
                combination.type = indexPath.row
                self.navigationController?.pushViewController(combination, animated: true)
            }
            if  indexPath.section == 1 {
                let combination = KeyFrameAnimationVC()
                combination.type = indexPath.row
                self.navigationController?.pushViewController(combination, animated: true)
            }
            if  indexPath.section == 2 {
                let combination = GroupAnimationVC()
                combination.type = indexPath.row
                self.navigationController?.pushViewController(combination, animated: true)
            }
            if  indexPath.section == 3 {
                let combination = TransitionAnimationVC()
                combination.type = indexPath.row
                self.navigationController?.pushViewController(combination, animated: true)
            }
            if  indexPath.section == 4 {
                let combination = CombinationAniVC()
                combination.type = indexPath.row
                self.navigationController?.pushViewController(combination, animated: true)
            }
        }).disposed(by: disposeBag)

        items.asObservable().bind(to: tableView.rx.items(dataSource: dataSoucre)).disposed(by: disposeBag)
        
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
        tableView.rx.setDelegate(self).disposed(by: disposeBag)
    }

}

extension AnimationLisVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
}
