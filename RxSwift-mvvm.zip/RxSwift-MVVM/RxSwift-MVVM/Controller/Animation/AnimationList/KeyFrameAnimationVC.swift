//
//  KeyFrameAnimationVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/21.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class KeyFrameAnimationVC: ViewController {

    var type = Int()
    var babyView = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = type == 0 ? "关键帧" : type == 1 ? "路径" : "抖动"
        creatBabyView()
        creatAnimationm()
    }
    
    func creatBabyView() {
        babyView = UIView.init(frame: CGRect.init(x: (kScreenWidth - 100)/2, y: kScreenHeight/2 - 100, width: 100, height: 100))
        babyView.backgroundColor = UIColor.red
        self.view.addSubview(babyView)
    }
    
    func creatAnimationm(){
        switch (type) {
            case 0:
                makeKeyFrameAnimation()
                break
            case 1:
                makePathAnimation()
                break
            case 2:
                makeShakeAnimation()
                break
            default:
                break
        }
    }

    //关键帧动画
    func makeKeyFrameAnimation(){
        let animation = CAKeyframeAnimation.init(keyPath: "position")
        let value_0 = NSValue.init(cgPoint: CGPoint.init(x: 50, y: kScreenHeight/2 - 50))
        let value_1 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth/3, y: kScreenHeight/2 - 50))
        let value_2 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth/3, y: kScreenHeight/2 + 50))
        let value_3 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth*2/3, y: kScreenHeight/2 + 50))
        let value_4 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth*2/3, y: kScreenHeight/2 - 50))
        let value_5 = NSValue.init(cgPoint: CGPoint.init(x: kScreenWidth-50, y: kScreenHeight/2 - 50))
        animation.values = [value_0,value_1,value_2,value_3,value_4,value_5]
        animation.duration = 2
        babyView.layer.add(animation, forKey: "keyFrameAnimation")
    }

    //路径
    func makePathAnimation(){
        let animation = CAKeyframeAnimation.init(keyPath: "position")
        let path = UIBezierPath.init(arcCenter: CGPoint.init(x: kScreenWidth/2, y: kScreenHeight/2), radius: 60, startAngle: 0, endAngle: .pi*2, clockwise: true)
        animation.duration = 2.0;
        animation.path = path.cgPath;
        babyView.layer.add(animation, forKey: "pathAnimation");
    }

    //抖动动画
    func makeShakeAnimation(){
        let animation = CAKeyframeAnimation.init(keyPath: "transform.rotation");
        let value_0 = NSNumber.init(floatLiteral: -.pi/180*4)
        let value_1 = NSNumber.init(floatLiteral: .pi/180*4)
        let value_2 = NSNumber.init(floatLiteral: -.pi/180*4)
        animation.values = [value_0,value_1,value_2];
        animation.repeatCount = MAXFLOAT;
        babyView.layer.add(animation, forKey: "shakeAnimation");
    }

}
