//
//  TransitionAnimationVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/21.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class TransitionAnimationVC: ViewController {

    var type = Int()
    var index = Int()
    var babyView = UIView()
    var numLabel = UILabel()
    override func viewDidLoad() {
        super.viewDidLoad()
        creatHomePageNavgation()
        creatBabyView()
    }
    
    // MARK: - 创建自定义导航
    func creatHomePageNavgation() {
        let array = ["fade","moveIn","push","reveal","cube","suck","oglFile","ripple","curl","unCurl","caOpen","caClose"];
        self.navigationItem.title = array[type]
    }
    
    /// 创建动画View
    func creatBabyView() {
        babyView = UIView.init(frame: CGRect.init(x: (kScreenWidth - 100)/2, y: kScreenHeight/2 - 100, width: 100, height: 100))
        babyView.backgroundColor = UIColor.red
        self.view.addSubview(babyView)
        numLabel = UILabel.init(frame: CGRect.init(x: 37.5, y: 30, width: 25, height: 40))
        numLabel.textAlignment = NSTextAlignment.center
        numLabel.font = UIFont.systemFont(ofSize: 40)
        babyView.addSubview(numLabel)
        let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 100, height: 100))
        button.addTarget(self, action: #selector(creatAnimationm), for: UIControl.Event.touchUpInside)
        babyView.addSubview(button)
    }

    @objc func creatAnimationm() {
        switch (type) {
            case 0:
                fade()
                break
            case 1:
                moveIn()
                break
            case 2:
                push()
                break
            case 3:
                reveal()
                break
            case 4:
                cube()
                break;
            case 5:
                suck()
                break
            case 6:
                oglFile()
                break
            case 7:
                ripple()
                break
            case 8:
                curl()
                break
            case 9:
                unCurl()
                break
            case 10:
                caOpen()
                break
            case 11:
                caClose()
                break
            default:
                break
        }
    }

    func fade(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType.fade;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "fadeAnimation")
    }

    func moveIn(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType.moveIn;
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "moveInAnimation")
    }

    func push(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType.push;
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "pushAnimation")
    }

    func reveal(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType.reveal
        transitionAni.subtype = CATransitionSubtype.fromRight
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "revealAnimation")
    }

    func cube(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType(rawValue: "cube")
        transitionAni.subtype = CATransitionSubtype.fromRight
        transitionAni.duration = 1.0
        babyView.layer.add(transitionAni, forKey: "cubeAnimation")
    }

    func suck(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType(rawValue: "suckEffect")
        transitionAni.subtype = CATransitionSubtype.fromRight
        transitionAni.duration = 1.0
        babyView.layer.add(transitionAni, forKey: "suckAnimation")
    }

    func oglFile(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType(rawValue: "oglFlip")
        transitionAni.subtype = CATransitionSubtype.fromRight
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "oglFileAnimation")
    }

    func ripple(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType(rawValue: "rippleEffect")
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "rippleAnimation")
    }

    func curl(){
        addNumToLabel()
        let transitionAni = CATransition.init()
        transitionAni.type = CATransitionType(rawValue: "pageCurl")
        transitionAni.subtype = CATransitionSubtype.fromRight
        transitionAni.duration = 1.0
        babyView.layer.add(transitionAni, forKey: "curlAnimation")
    }

    func unCurl(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType(rawValue: "pageUnCurl");
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "unCurlAnimation")
    }

    func caOpen(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType(rawValue: "cameraIrisHollowOpen");
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "caOpenAnimation")
    }

    func caClose(){
        addNumToLabel()
        let transitionAni = CATransition.init();
        transitionAni.type = CATransitionType(rawValue: "cameraIrisHollowClose");
        transitionAni.subtype = CATransitionSubtype.fromRight;
        transitionAni.duration = 1.0;
        babyView.layer.add(transitionAni, forKey: "caCloseAnimation")
    }
    
    func addNumToLabel(){
        if index > 3 {
            index = 0;
        }
        let colors = [UIColor.cyan,UIColor.magenta,UIColor.green,UIColor.purple]
        let numArray = ["1","2","3","4"]
        self.babyView.backgroundColor = colors[index];
        self.numLabel.text = numArray[index];
        index+=1;
    }
}
