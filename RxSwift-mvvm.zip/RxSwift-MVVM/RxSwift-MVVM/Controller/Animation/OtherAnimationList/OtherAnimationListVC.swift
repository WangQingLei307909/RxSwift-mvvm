//
//  OtherAnimationListVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/4/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxDataSources
import RxCocoa
class OtherAnimationListVC: ViewController {

    @IBOutlet weak var tableView: UITableView!
    
    let disposeBag = DisposeBag()
    
    let items = Observable.just([SectionModel(model: "MGEffectStyle", items: ["MGEffectStyleDrop",
                                                                              "MGEffectStyleThimble",
                                                                              "MGEffectStyleCircle",
                                                                              "MGEffectStyleStrip",
                                                                              "MGEffectStyleWoody",
                                                                              "MGEffectStyleShape",
                                                                              "MGEffectStyleLinear",
                                                                              "MGEffectStyleInverted"]),
                                 SectionModel(model: "MGLosderStyle", items: ["MGLoaderStyleTriangle",
                                                                              "MGLoaderStyleCationDot",
                                                                              "MGLoaderStyleExpandDot",
                                                                              "MGLoaderStyleShipDot",
                                                                              "MGLoaderStyleChain",
                                                                              "MGLoaderStyleAlter",
                                                                              "MGLoaderStyleAlternation",
                                                                              "MGLoaderStyleRotaDot"])])
    
    
    let dataSource = RxTableViewSectionedReloadDataSource<SectionModel<String,String>>(configureCell:{ (dataSouece, tableView, indexPath, item) -> WGIOSKnowViewCell in
        let cell = tableView.dequeueReusableCell(withIdentifier: "WGIOSKnowViewCell", for: indexPath) as! WGIOSKnowViewCell
        cell.titleLabel.textColor = .randomColor()
        cell.titleLabel.text = item
        return cell
    },titleForHeaderInSection: { dataSource, indexPath in
        return dataSource[indexPath].model
    })
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        items.asObservable().bind(to: tableView.rx.items(dataSource: dataSource)).disposed(by: disposeBag)
        tableView.register(UINib.init(nibName: cellIdentify, bundle: nil), forCellReuseIdentifier: cellIdentify)
        tableView.rx.setDelegate(self).disposed(by: disposeBag)
        
        tableView.rx.itemSelected.subscribe(onNext: { indexPath in
            let animation = AnimationShowVC()
            animation.row = indexPath.row
            animation.section = indexPath.row
            self.navigationController?.pushViewController(animation, animated: true)
            }).disposed(by: disposeBag)
    }

}

extension OtherAnimationListVC:UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return WGIOSKnowViewCell.cellHeight()
    }
}
