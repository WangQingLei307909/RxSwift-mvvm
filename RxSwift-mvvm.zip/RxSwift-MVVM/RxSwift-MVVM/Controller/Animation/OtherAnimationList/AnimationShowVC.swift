//
//  AnimationShowVC.swift
//  AmzingBox
//
//  Created by abox on 2020/8/28.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit

class AnimationShowVC: ViewController {
    
    var section = Int()
    var row = Int()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = section == 0 ? "MGEffectStyle" : "MGLosderStyle"
        creatAnimation()
    }
    
    
    func creatAnimation() {
        if section == 0 {
            let showView = MGShowView.show(withType: MGEffectStyle.init(rawValue: section)!)
            self.view.addSubview(showView!)
        } else {
            let loaderView = MGLoaderView.loader()
            loaderView?.style = MGLoaderStyle.init(rawValue: section)!
            loaderView?.centerX = self.view.centerX
            loaderView?.centerY = self.view.centerY
            self.view.addSubview(loaderView!)
            let patterView = MGPatternView.init(frame: CGRect.init(x: kScreenWidth - 50, y: kScreenHeight - CGFloat(kSafeAreaTopHeight), width: 50, height: 50))
            patterView.motorDirection = MGMotorDirection.up;
            patterView.subViews = countItems() as? [UIButton];
            patterView.patterviewBlock = { index in
                self.selectLoaderStyle(style: index)
            }
            self.view.addSubview(patterView)
        }
    }

    func selectLoaderStyle(style:Int) {
        for view in self.view!.subviews {
            if !view.isKind(of: MGPatternView.self) {
                view.removeFromSuperview()
            }
        }
        let loaderView = MGLoaderView.loader();
        loaderView?.centerX       = self.view.centerX;

        loaderView?.centerY       = self.view.centerY;

        loaderView?.style = MGLoaderStyle(rawValue: style)!;
        
        self.view.addSubview(loaderView!)
        
    }

    
    func countItems() -> NSArray {
        let buttonsMutable = NSMutableArray()
        let i = 0
        let array = ["A", "B", "C", "D", "E", "F"]
        for title:String in array {
            let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 30, height: 30))
            button.setTitle(title, for: UIControl.State.normal)
            button.setTitleColor(UIColor.white, for: UIControl.State.normal)
            button.layer.cornerRadius = 15
            button.backgroundColor = UIColor.init(displayP3Red: 0, green: 0, blue: 0, alpha: 0.4)
            button.clipsToBounds = true
            button.tag = i + 1
            button.addTarget(self, action: #selector(dwBtnClick), for: UIControl.Event.touchUpInside)
            buttonsMutable.add(button)
        }
        return buttonsMutable;
    }
    
    @objc func dwBtnClick(button:UIButton) {
        
    }
    
}
