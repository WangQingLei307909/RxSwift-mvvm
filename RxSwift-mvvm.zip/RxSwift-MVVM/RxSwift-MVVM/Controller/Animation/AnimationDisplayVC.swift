//
//  AnimationDisplayVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/4/23.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class AnimationDisplayVC: ViewController {

    let sphereView = DBSphereView()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "动画展示"
        initSphereView()
    }

}

extension AnimationDisplayVC {
    func initSphereView() {
        sphereView.frame = CGRect.init(x: 40, y: 200, width: kScreenWidth - 80, height: kScreenWidth - 80)
        let array = NSMutableArray()
        for i in 0..<50 {
            let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 20))
            button.setTitle("P\(i)", for: UIControl.State.normal)
            button.setTitleColor(.randomColor(), for: UIControl.State.normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 24)
            button.tag = i + 1
            button.addTarget(self,action:#selector(buttonPressed),for:.touchUpInside)
            array.add(button)
            sphereView.addSubview(button)
        }
        sphereView.setCloudTags(array as? [Any])
        sphereView.backgroundColor = UIColor.white
        self.view.addSubview(sphereView)
    }
    
    @objc func buttonPressed(button:UIButton) {
        sphereView.timerStop()
        if button.tag % 2 == 1  {
            self.navigationController?.pushViewController(OtherAnimationListVC(), animated: true)
        } else {
            self.navigationController?.pushViewController(AnimationLisVC(), animated: true)
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        sphereView.timerStart()
    }
}
