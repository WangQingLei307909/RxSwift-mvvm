//
//  RxSwiftControlPropertyVC.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/25.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RxSwiftControlPropertyVC: ViewController {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ControlProperty()
        ControlEvent()
    }
    
    /*
     (1）ControlProperty 是专门用来描述 UI 控件属性，拥有该类型的属性都是被观察者（Observable）。
     (2) ControlProperty 具有以下特征：
       1、不会产生 error 事件
       2、一定在 MainScheduler 订阅（主线程订阅）
       3、一定在 MainScheduler 监听（主线程监听）
       4、共享状态变化
     */
    func ControlProperty() {
        /*
         在RxCocoa中，拥有ControlProperty这个属性的控件都是被观察者
         那么我们如果想让一个 textField 里输入内容实时地显示在另一个 label 上，即前者作为被观察者，后者作为观察者。
         */
        textField.rx.text.bind(to: label.rx.text).disposed(by: disposeBag)
    }
    
    /*
    （1）ControlEvent 是专门用于描述 UI 所产生的事件，拥有该类型的属性都是被观察者（Observable）。
    （2）ControlEvent 和 ControlProperty 一样，都具有以下特征：
        1、不会产生 error 事件
        2、一定在 MainScheduler 订阅（主线程订阅）
        3、一定在 MainScheduler 监听（主线程监听）
        4、共享状态变化
    */
    func ControlEvent() {
        button.rx.tap.subscribe(onNext: {
            print($0)
        }).disposed(by: disposeBag)
    }
    
}
