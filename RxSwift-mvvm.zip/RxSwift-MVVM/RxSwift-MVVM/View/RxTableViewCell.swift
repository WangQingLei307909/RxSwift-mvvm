//
//  RxTableViewCell.swift
//  RxSwift-Table-Collection
//
//  Created by iOS_Tian on 2017/9/15.
//  Copyright © 2017年 iOS_Tian. All rights reserved.
//

import UIKit

class RxTableViewCell: UITableViewCell {

    @IBOutlet weak var headImage: UIImageView!
    @IBOutlet weak var focusLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    var anchorModel: AnchorModel? {
        didSet{
            guard let model = anchorModel else { return }
            nameLabel.text = model.title
            nameLabel.textColor = SwiftColor.randomColor()
            focusLabel.text = "类型\(model.category)"
            focusLabel.textColor = .randomColor()
            headImage.kf.setImage(with: URL(string: model.thumb_url), placeholder: UIImage(named: "216813987373"), options: nil, progressBlock: nil) { (reslt) in
            }
        }
    }
    
    
    public static func height() -> CGFloat {
        return 90
    }
}
