//
//  WGIOSKnowViewCell.swift
//  WGNewsProject
//
//  Created by abox on 2021/1/12.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class WGIOSKnowViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        darkMode()
    }
    
    func darkMode() {
        if #available(iOS 11.0, *) {
            self.backgroundColor = UIColor(named: "bgcolor")
            titleLabel.textColor = UIColor(named: "titlecolor")
        } else {
            self.backgroundColor = SwiftColor.bgViewColor
            titleLabel.textColor = SwiftColor.TitleColor
        }
    }
    
    public static func cellHeight() -> CGFloat {
        return 45
    }
    
    public func setCellData(string:String) {
        titleLabel.text = string
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
