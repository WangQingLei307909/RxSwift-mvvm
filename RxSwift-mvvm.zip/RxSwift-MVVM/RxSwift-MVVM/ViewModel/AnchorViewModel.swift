//
//  AnchorViewModel.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import CLToast
import RxCocoa
import Alamofire
import SVProgressHUD
class AnchorViewModel: NSObject {
    
    let anchorArr = Variable<[AnchorModel]>([])
    var index: Int = 0
}

extension AnchorViewModel: ViewModelType {
    
    typealias Input = WeiInput
    
    typealias Output = WeiOutput
    
    
    struct WeiInput {
        let category: NetworkTool
        
        init(category: NetworkTool) {
            self.category = category
        }
        
    }
    
    struct WeiOutput {
        let sections: Driver<[AnchorSection]>
        let requestCommond = PublishSubject<Bool>()
        let refreshStatus = Variable<RefreshStatus>(.none)
        //初始化时,section的数据
        init(sections: Driver<[AnchorSection]>) {
            self.sections = sections
        }
    }
    
    func tranform(input: AnchorViewModel.WeiInput) -> AnchorViewModel.WeiOutput {
        
        let sectionArray = anchorArr.asDriver().map { ( models ) -> [AnchorSection] in
            return [AnchorSection(items: models)]
        }.asDriver(onErrorJustReturn:[])
        
        let output = WeiOutput(sections: sectionArray)
        
        output.requestCommond.subscribe(onNext: { ( isReloadData ) in
            self.index = isReloadData ? 1 : self.index + 1
            //开始请求数据
            SVProgressHUD.show()
            weiNetworkTool.rx.request(.getHomeList(page: self.index)).asObservable().mapArray(AnchorModel.self).subscribe({[weak self] (event) in
                SVProgressHUD.dismiss()
                switch event {
                    case let .next(modelArr):
                        self!.anchorArr.value = isReloadData ? modelArr : (self!.anchorArr.value) + modelArr
                        CLToast.cl_show(msg: "加载成功")
                    case let .error(error):
                        CLToast.cl_show(msg: error.localizedDescription)
                    case .completed:
                        output.refreshStatus.value = isReloadData ? .endHeaderRefresh : .endFooterRefresh
                }
            }).disposed(by: disposeBag)
        }).disposed(by:disposeBag)
        return output
    }
    
}
