//
//  AnchorGirlViewModel.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import CLToast
import RxCocoa
import Alamofire
import WisdomHUD

class AnchorGirlViewModel: NSObject {
    //创建数据源，用来存储请求返回的数据
    let anchorArr = Variable<[AnchorModel]>([])
    //请求接口的分页参数
    var index: Int = 0
}

// MARK: - 遵守协议，使用协议的参数和方法
extension AnchorGirlViewModel: ViewModelType {

    typealias Input = WeiInput
    
    typealias Output = WeiOutput
    
    
    struct WeiInput {
        var category = BehaviorRelay<NetworkTool.GirlCategory>(value: .GirlCategoryAll)
        init(category: BehaviorRelay<NetworkTool.GirlCategory>) {
            self.category = category
        }
        
    }
    
    struct WeiOutput {
        let sections: Driver<[AnchorSection]>
        let requestCommond = PublishSubject<Bool>()
        let refreshStatus = Variable<RefreshStatus>(.none)
        //初始化时,section的数据
        init(sections: Driver<[AnchorSection]>) {
            self.sections = sections
        }
    }

    func tranform(input: AnchorGirlViewModel.WeiInput) -> AnchorGirlViewModel.WeiOutput {
        let sections = anchorArr.asObservable().map{ (models) -> [AnchorSection] in
            return [AnchorSection(items: models)]
        }.asDriver(onErrorJustReturn: [])
        
        let output = WeiOutput(sections: sections)
        
        input.category.asObservable().subscribe {
            let category = $0.element
            output.requestCommond.subscribe(onNext: { ( isReloadData ) in
                self.index = isReloadData ? 1 : self.index + 1
                WisdomHUD.showLoading(text: "加载中", enable: true)
                weiNetworkTool.rx.request(.getListCategory(category: category!, page: self.index)).asObservable().mapArray(AnchorModel.self).subscribe({[weak self] (event) in
                    WisdomHUD.dismiss()
                    switch event {
                        case let .next(modelArr):
                            self!.anchorArr.value = isReloadData ? modelArr : (self!.anchorArr.value) + modelArr
                            CLToast.cl_show(msg: "加载成功")
                        case let .error(error):
                            CLToast.cl_show(msg: error.localizedDescription)
                        case .completed:
                            output.refreshStatus.value = isReloadData ? .endHeaderRefresh : .endFooterRefresh
                    }
                }).disposed(by: disposeBag)
                
            }).disposed(by:disposeBag)
            
        }.disposed(by: disposeBag)
        return output
    }
    
}

