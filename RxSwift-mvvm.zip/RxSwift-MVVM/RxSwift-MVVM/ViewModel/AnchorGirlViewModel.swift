//
//  AnchorGirlViewModel.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import RxSwift
import CLToast
import RxCocoa
import Alamofire
import WisdomHUD

class AnchorGirlViewModel: NSObject {
    //创建数据源，用来存储请求返回的数据
    let anchorArr = Variable<[AnchorModel]>([])
    //请求接口的分页参数
    var index: Int = 0
}

// MARK: - 遵守协议，使用协议的参数和方法
extension AnchorGirlViewModel: ViewModelType {
    
    //遵守协议后入参（别名）
    typealias Input = WeiInput
    
    //遵守协议后出参（别名）
    typealias Output = WeiOutput
    
    //定义入参结构体
    struct WeiInput {
        //设置请求参数category的默认值BehaviorRelay（既可以发送消息，也可以进行订阅）
        var category = BehaviorRelay<NetworkTool.GirlCategory>(value: .GirlCategoryAll)
        //构造方法
        init(category: BehaviorRelay<NetworkTool.GirlCategory>) {
            self.category = category
        }
        
    }
    
    //定义出参结构体
    struct WeiOutput {
        //创建Driver序列化
        let sections: Driver<[AnchorSection]>
        //创建PublishSubject发送和观察其值内容的变化
        let requestCommond = PublishSubject<Bool>()
        //创建Variable并设置默认值，并且发送和观察其值内容的变化
        let refreshStatus = Variable<RefreshStatus>(.none)
        //初始化时,section的数据
        init(sections: Driver<[AnchorSection]>) {
            self.sections = sections
        }
    }
    
    /// 调用请求的方法
    /// - Parameter input: 入参数
    func tranform(input: AnchorGirlViewModel.WeiInput) -> AnchorGirlViewModel.WeiOutput {
        /*
         对anchorArr进行订阅，当anchorArr内容变化的时候，这里就会收到对应的数据。
         然后对返回数据，设置成RxDataSource的所需要的数据类型。
         */
        let sections = anchorArr.asObservable().map{ (models) -> [AnchorSection] in
            return [AnchorSection(items: models)]
            //MARK:- 设置分组功能，如果不适用分组下面代码注释掉
            /*
             return [AnchorSection(title: "分组1", items: models),
                     AnchorSection(title: "分组2", items: models),
                     AnchorSection(title: "分组3", items: models)]
             */
        }.asDriver(onErrorJustReturn: [])
        
        //创建WeiOutputb调用WeiOutput的构造方法，并将数据返回
        let output = WeiOutput(sections: sections)
        //订阅category，观察其内容的变化，当变化的时候就会执行下面的方法。
        input.category.asObservable().subscribe {
            //获取观察后的类型
            let category = $0.element
            // 观察下拉刷新或者上拉加载变化，当下拉刷新或者加载的时候就会执行下面方法
            output.requestCommond.subscribe(onNext: { ( isReloadData ) in
                //根据isReloadData的内容，判断index值是增加还是恢复初始值
                self.index = isReloadData ? 1 : self.index + 1
                //展示加载提示
                WisdomHUD.showLoading(text: "加载中", enable: true)
                /*
                 请求数据，category 参数 ，page 页数
                 对请求的数据进行观察，对观察到的返回结果进行mapArray解析，对解析后的数据进行观察，返回对应的结果
                 .next 成功（返回结果），error 错误内容，completed完成
                 */
                weiNetworkTool.rx.request(.getListCategory(category: category!, page: self.index)).asObservable().mapArray(AnchorModel.self).subscribe({[weak self] (event) in
                    WisdomHUD.dismiss()
                    switch event {
                        case let .next(modelArr):
                            self!.anchorArr.value = isReloadData ? modelArr : (self!.anchorArr.value) + modelArr
                            CLToast.cl_show(msg: "加载成功")
                        case let .error(error):
                            CLToast.cl_show(msg: error.localizedDescription)
                        case .completed:
                            output.refreshStatus.value = isReloadData ? .endHeaderRefresh : .endFooterRefresh
                    }
                }).disposed(by: disposeBag)
                
            }).disposed(by:disposeBag)
            
        }.disposed(by: disposeBag)
        return output
    }
    
}

