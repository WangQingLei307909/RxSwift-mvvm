//
//  MoyaBaseUrl.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

let BaseUrl = "https://meizi.leanapp.cn"

//请求返回状态
enum NetworkRequestState: Int {
    case success = 200
    case error
}
