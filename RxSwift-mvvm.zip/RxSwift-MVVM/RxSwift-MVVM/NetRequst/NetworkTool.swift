//
//  NetworkTool.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import Moya
import RxSwift
import Alamofire
/// 超时时长
private var requestTimeOut:Double = 30


// MARK: - 这里对当前工具类进行了两种封装第一种就是简单的网络请求接口暴露，另一种就是比较复杂的数据请求方式（可以设置每一个API超时时常、设置统一Token、设置SSL证书、设置当前请求过程等），由于这个当前项目是一个演示demo，这里没有使用过于复杂的请求方式。采用了第一种方式

// MARK: - 第一种，直接就是一个请求的作用，其他都是默认设置
var weiNetworkTool = MoyaProvider<NetworkTool>()

// MARK: - 第二种，设置了多种功能超时时常、设置统一Token、设置SSL证书、设置当前请求过程等，如果程序对请求有要求，那么就要使用第二种
// MARK: ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ 第二种方式 ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️ ⬇️
 
 //把session当参数传进去就行了
 let kProvider = MoyaProvider<NetworkTool>(endpointClosure: myEndpointClosure, requestClosure: requestClosure, session: session, plugins: [networkPlugin], trackInflights: false)

 // 设置 SSL
 let session : Session = {
    //证书数据
    func certificate() -> SecCertificate? {
        let filePath = Bundle.main.path(forResource: "存在Xcode中证书的文件名", ofType: "cer")
        if filePath == nil {
            return nil
        }
        let data = try! Data(contentsOf: URL(fileURLWithPath: filePath ?? ""))
        let certificate = SecCertificateCreateWithData(nil, data as CFData)!
        return certificate
    }
    guard let certificate = certificate() else {
        return Session()
    }
    let trusPolicy = PinnedCertificatesTrustEvaluator(certificates: [certificate], acceptSelfSignedCertificates: false, performDefaultValidation: true, validateHost: true)
    let trustManager = ServerTrustManager(evaluators: ["你证书的域名，比如www.baidu.com或者baidu.com" : trusPolicy])
    let configuration = URLSessionConfiguration.af.default
    return Session(configuration: configuration, serverTrustManager: trustManager)
 }()

 ///网络请求的基本设置,这里可以拿到是具体的哪个网络请求，可以在这里做一些设置
 private let myEndpointClosure = { (target: NetworkTool) -> Endpoint in
     ///这里把endpoint重新构造一遍主要为了解决网络请求地址里面含有? 时无法解析的bug https://github.com/Moya/Moya/issues/1198
     let url = target.baseURL.absoluteString + target.path
     var task = target.task
     /*
      如果需要在每个请求中都添加类似token参数的参数请取消注释下面代码
      👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇
      */
 //    let additionalParameters = ["token":"888888"]
 //    let defaultEncoding = URLEncoding.default
 //    switch target.task {
 //        ///在你需要添加的请求方式中做修改就行，不用的case 可以删掉。。
 //    case .requestPlain:
 //        task = .requestParameters(parameters: additionalParameters, encoding: defaultEncoding)
 //    case .requestParameters(var parameters, let encoding):
 //        additionalParameters.forEach { parameters[$0.key] = $0.value }
 //        task = .requestParameters(parameters: parameters, encoding: encoding)
 //    default:
 //        break
 //    }
     /*
      👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆
      如果需要在每个请求中都添加类似token参数的参数请取消注释上面代码
      */
     var endpoint = Endpoint(
         url: url,
         sampleResponseClosure: { .networkResponse(200, target.sampleData) },
         method: target.method,
         task: task,
         httpHeaderFields: target.headers
     )
     requestTimeOut = 30//每次请求都会调用endpointClosure 到这里设置超时时长 也可单独每个接口设置
     switch target {
     case .getHomeList:
         return endpoint
     default:
         return endpoint
     }
 }

 ///网络请求的设置
 private let requestClosure = { (endpoint: Endpoint, done: MoyaProvider.RequestResultClosure) in
     do {
         var request = try endpoint.urlRequest()
         //设置请求时长
         request.timeoutInterval = requestTimeOut
         // 打印请求参数
         if let requestData = request.httpBody {
             print("\(request.url!)"+"\n"+"\(request.httpMethod ?? "")"+"发送参数"+"\(String(data: request.httpBody!, encoding: String.Encoding.utf8) ?? "")")
         }else{
             print("\(request.url!)"+"\(String(describing: request.httpMethod))")
         }
         done(.success(request))
     } catch {
         done(.failure(MoyaError.underlying(error, nil)))
     }
 }

 /// NetworkActivityPlugin插件用来监听网络请求，界面上做相应的展示
 ///但这里我没怎么用这个。。。 loading的逻辑直接放在网络处理里面了
 private let networkPlugin = NetworkActivityPlugin.init { (changeType, targetType) in
     print("networkPlugin \(changeType)")
     //targetType 是当前请求的基本信息
     switch(changeType){
     case .began:
         print("开始请求网络")
     case .ended:
         print("结束")
     }
 }

// MARK: ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ 第二种方式 ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️ ⬆️
// MARK: -

enum NetworkTool {
    
    enum GirlCategory: String{
        
        case GirlCategoryAll = "All"
        case GirlCategoryDaXiong = "DaXiong"
        case GirlCategoryQiaoTun = "QiaoTun"
        case GirlCategoryHeisi = "Heisi"
        case GirlCategoryMeiTui = "MeiTui"
        case GirlCategoryQingXin = "QingXin"
        case GirlCategoryZaHui = "ZaHui"
    }
    
    static func indexToCategory(index: Int) -> GirlCategory{
        var category: GirlCategory
        switch index {
        case 0:
           category = GirlCategory.GirlCategoryAll
            break
        case 1:
            category = GirlCategory.GirlCategoryDaXiong
            break
        case 2:
            category = GirlCategory.GirlCategoryQiaoTun
            break
        case 3:
            category = GirlCategory.GirlCategoryHeisi
            break
        case 4:
            category = GirlCategory.GirlCategoryMeiTui
            break
        case 5:
            category = GirlCategory.GirlCategoryQingXin
            break
        case 6:
            category = GirlCategory.GirlCategoryZaHui
            break
        default:
           category = GirlCategory.GirlCategoryAll
        }
        return category
    }
    /*
      get
     */
    case getHomeList(page: Int)
    case getListCategory(category:GirlCategory, page: Int)
    case getRequst
    /*
      put
     */
    case putRequst(paramterDic:NSDictionary)
    /*
      delete
     */
    case deleteRequst(paramterDic:NSDictionary)
    /*
      update
     */
    case userLogin(paramterDic:NSDictionary)
    case userRegister(paramterDic:NSDictionary)
    case uploadHeadImage(parameters: [String:Any],imageDate:Data)//上传图片
}

extension NetworkTool: TargetType {
    var baseURL: URL {
        switch self {
        /*
          get请求
         */
        case .getRequst:
            return URL.init(string:(BaseUrl))!
        /*
          put请求
         */
        case .putRequst:
            return URL.init(string:(BaseUrl))!
        /*
          delete请求
         */
        case .deleteRequst:
            return URL.init(string:(BaseUrl))!
        /*
          post请求
         */
        default:
            return URL.init(string:(BaseUrl))!
        }
    }
    
        /// The path to be appended to `baseURL` to form the full `URL`.
    var path: String{
        switch self {
        /*
          get请求
         */
        case .getRequst:
            return "sys/user/changePassword"
        case .getHomeList(let page):
            return "/category/All/page/\(page)" //此处因为是枚举值，必须使用category.rawValue，否则请求不到数据
        case .getListCategory(let category,let page):
            return "/category/\(category.rawValue)/page/\(page)" //此处因为是枚举值，必须使用category.rawValue，否则请求不到数据
        /*
          put请求
         */
        case .putRequst:
            return "sys/user/changePassword"
        /*
          put请求
         */
        case .deleteRequst:
            return "sys/user/changePassword"
        /*
          post请求
        */
        case .userRegister:
            return "sys/user/register"
        case .userLogin:
            return "sys/mLogin"
        case .uploadHeadImage( _):
            return "file/user/upload.jhtml"
        }
        
    }
    
    var method: Moya.Method {
        switch self {
        case .getRequst:
            return .get
        case .getHomeList:
            return .get
        case .getListCategory:
            return .get
        case .putRequst:
            return .put
        case .deleteRequst:
            return .delete
        default:
            return .post
        }
    }
    
    var sampleData: Data {
        return "getList".data(using: .utf8)!
    }
    
    //    该条请API求的方式,把参数之类的传进来
    var task: Task {
//        return .requestParameters(parameters: nil, encoding: JSONArrayEncoding.default)
        switch self {
        /*
          get请求
         */
        case .getRequst:
            return .requestPlain
        case .getHomeList:
            return .requestPlain
        case .getListCategory:
            return .requestPlain
        /*
          post请求
         */
        case let .userLogin(parameters):
            return .requestParameters(parameters: parameters as! [String : Any], encoding: JSONEncoding.default)
        case let .userRegister(parameters):
            return .requestParameters(parameters: parameters as! [String : Any], encoding: JSONEncoding.default)
        /*
          put请求
         */
        case let .putRequst(parameters):
            return .requestParameters(parameters: parameters as! [String : Any], encoding: URLEncoding.default)
        /*
          获取新闻列表
         */
        case let .deleteRequst(parameters):
            return .requestParameters(parameters: parameters as! [String : Any], encoding: URLEncoding.default)
        /*
          图片上传
         */
        case .uploadHeadImage(let parameters, let imageDate):
            ///name 和fileName 看后台怎么说，   mineType根据文件类型上百度查对应的mineType
            let formData = MultipartFormData(provider: .data(imageDate), name: "file",
                                              fileName: "hangge.png", mimeType: "image/png")
            return .uploadCompositeMultipart([formData], urlParameters: parameters)

        }
        
        //可选参数https://github.com/Moya/Moya/blob/master/docs_CN/Examples/OptionalParameters.md
//        case .users(let limit):
//        var params: [String: Any] = [:]
//        params["limit"] = limit
//        return .requestParameters(parameters: params, encoding: URLEncoding.default)
    }
    
    var headers: [String : String]?{
//        return ["Content-Type":"application/x-www-form-urlencoded","Content-type": "application/json"]
        return ["Content-type": "application/json"]
    }
    
    //是否执行Alamofire验证，默认值为false
    var validate: Bool {
        return false
    }
    
}
