//
//  NetworkTool.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/3/22.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit
import Moya
import RxSwift

let disposeBag = DisposeBag()
var weiNetworkTool = MoyaProvider<NetworkTool>()
//////网络请求发送的核心初始化方法，创建网络请求对象
//let weiNetworkTool = MoyaProvider<NetworkTool>(endpointClosure: myEndpointClosure, trackInflights: false)
//
/////网络请求的基本设置,这里可以拿到是具体的哪个网络请求，可以在这里做一些设置
//private let myEndpointClosure = { (target: NetworkTool) -> Endpoint in
//    ///这里把endpoint重新构造一遍主要为了解决网络请求地址里面含有? 时无法解析的bug https://github.com/Moya/Moya/issues/1198
//    let url = target.baseURL.absoluteString + target.path
//    var task = target.task
//    
//    /*
//     如果需要在每个请求中都添加类似token参数的参数请取消注释下面代码
//     👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇👇
//     */
////    let additionalParameters = ["token":"888888"]
////    let defaultEncoding = URLEncoding.default
////    switch target.task {
////        ///在你需要添加的请求方式中做修改就行，不用的case 可以删掉。。
////    case .requestPlain:
////        task = .requestParameters(parameters: additionalParameters, encoding: defaultEncoding)
////    case .requestParameters(var parameters, let encoding):
////        additionalParameters.forEach { parameters[$0.key] = $0.value }
////        task = .requestParameters(parameters: parameters, encoding: encoding)
////    default:
////        break
////    }
//    /*
//     👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆👆
//     如果需要在每个请求中都添加类似token参数的参数请取消注释上面代码
//     */
//    
//    
//    var endpoint = Endpoint(
//        url: url,
//        sampleResponseClosure: { .networkResponse(200, target.sampleData) },
//        method: target.method,
//        task: task,
//        httpHeaderFields: target.headers
//    )
//    return endpoint
//}
enum NetworkTool {
    
    enum GirlCategory: String{
        
        case GirlCategoryAll = "All"
        case GirlCategoryDaXiong = "DaXiong"
        case GirlCategoryQiaoTun = "QiaoTun"
        case GirlCategoryHeisi = "Heisi"
        case GirlCategoryMeiTui = "MeiTui"
        case GirlCategoryQingXin = "QingXin"
        case GirlCategoryZaHui = "ZaHui"
    }
    
    static func indexToCategory(index: Int) -> GirlCategory{
        var category: GirlCategory
        switch index {
        case 0:
           category = GirlCategory.GirlCategoryAll
            break
        case 1:
            category = GirlCategory.GirlCategoryDaXiong
            break
        case 2:
            category = GirlCategory.GirlCategoryQiaoTun
            break
        case 3:
            category = GirlCategory.GirlCategoryHeisi
            break
        case 4:
            category = GirlCategory.GirlCategoryMeiTui
            break
        case 5:
            category = GirlCategory.GirlCategoryQingXin
            break
        case 6:
            category = GirlCategory.GirlCategoryZaHui
            break
        default:
           category = GirlCategory.GirlCategoryAll
        }
        return category
    }
    
    case getHomeList(page: Int)
    case getListCategory(category:GirlCategory, page: Int)
}

extension NetworkTool: TargetType {
    var baseURL: URL {
        return URL(string: BaseUrl)!
    }
    
        /// The path to be appended to `baseURL` to form the full `URL`.
    var path: String{
        switch self{
        case .getHomeList(let page):
            return "/category/All/page/\(page)" //此处因为是枚举值，必须使用category.rawValue，否则请求不到数据
        case .getListCategory(let category,let page):
            return "/category/\(category.rawValue)/page/\(page)" //此处因为是枚举值，必须使用category.rawValue，否则请求不到数据
        }
    }
    
    var method: Moya.Method {
        return .get
    }
    
    var sampleData: Data {
        return "getList".data(using: .utf8)!
    }
    
    var task: Task {
        return .requestPlain
    }
    
    var headers: [String : String]?{
        return ["Content-type": "application/json"]
    }
    
    //是否执行Alamofire验证，默认值为false
    var validate: Bool {
        return false
    }
    
}
