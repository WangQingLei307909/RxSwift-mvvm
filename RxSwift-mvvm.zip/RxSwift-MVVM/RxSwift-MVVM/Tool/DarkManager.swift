//
//  DarkManager.swift
//  RxSwift-MVVM
//
//  Created by abox on 2021/4/1.
//  Copyright © 2021 wql. All rights reserved.
//

import UIKit

class DarkManager: NSObject {
    public static func setWindowDarkModeSwicth() {
        if #available(iOS 13.0, *) {
            let firstUseDarkMode = UserDefaults.standard.bool(forKey: "firstUseDarkMode")
            if firstUseDarkMode {
                let systemSwitchValue = UserDefaults.standard.bool(forKey: "systemSwitchValue")
                if !systemSwitchValue {
                    let darkSwitch = UserDefaults.standard.bool(forKey: "darkSwitchValue")
                    let window = UIApplication.shared.delegate?.window!!
                    window!.overrideUserInterfaceStyle = darkSwitch ? .dark : .light
                }
            } else {
                UserDefaults.standard.set(true, forKey: "systemSwitchValue")
            }
        }
    }
}
