//
//  SwiftTool.swift
//  AmzingBox
//
//  Created by abox on 2020/7/15.
//  Copyright © 2020 abox. All rights reserved.
//

import UIKit
import SystemConfiguration
import SystemConfiguration.CaptiveNetwork
import CommonCrypto
class SwiftTool: NSObject {
    
    // MARK: - 将jsonString转NSDictionary
    /// 将jsonString转NSDictionary
    /// - Parameter jsonString: json字符串
    public static func jsonStringToDict(jsonString:String) ->NSDictionary{
        let jsonData:Data = jsonString.data(using: .utf8)!
        let dict = try? JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers)
        if dict != nil {
            return dict as! NSDictionary
        }
        return NSDictionary()
    }
    
    // MARK: - 讲字典转成json字符串
    /// 讲字典转成json字符串
    /// - Parameter dictionary: d=字典
    func dictToJsonString(dictionary:NSDictionary) -> String {
        if (!JSONSerialization.isValidJSONObject(dictionary)) {
            print("无法解析出JSONString")
            return ""
        }
        let data : NSData! = try? JSONSerialization.data(withJSONObject: dictionary, options: []) as NSData?
        let JSONString = NSString(data:data as Data,encoding: String.Encoding.utf8.rawValue)
        return JSONString! as String
    }
    
    // MARK: - 获取本地的json文件
    /// 获取本地的json文件
    ///
    /// - Parameter fileName: 文件名称
    /// - Returns: 放回文件内容（字典）
    public static func readJsonFileByFileName(fileName : String) -> Any? {
        let path    = Bundle.main.path(forResource: "\(fileName).json", ofType: nil)
        let data    = NSData(contentsOfFile: path!)
        let jsonStr = try? JSONSerialization.jsonObject(with: data! as Data, options:.allowFragments)
        return jsonStr
    }
    
    // MARK: - 判断字符串是否为空
    /// 判断字符串是否为空
    /// - Parameter value: YES 是空
    public static func isEmptyOrNull(value: AnyObject?) -> Bool {
        //首先判断是否为nil
        if (nil == value) {
            //对象是nil，直接认为是空串
            return true
        } else {
            //然后是否可以转化为String
            if let myValue  = value as? String{
                //然后对String做判断
                return myValue == "" || myValue == "(null)" || 0 == myValue.count
            } else {
                //字符串都不是，直接认为是空串
                return true
            }
        }
    }
    
    // MARK: - 判断数组是否存在
    /// 判断数组是否存在
    ///
    /// - Parameter value: 判断的内容
    /// - Returns: 返回类型
    public static func arrayIsEmpty(value: AnyObject?) -> Bool {
        //首先判断是否为nil
        if ( nil == value ) {
            //对象是nil，直接认为是空数组
            return true;
        } else {
            //然后是否可以转化为空数组
            if let myValue  = value as? NSArray{
                //然后对空数组做判断
                return  0 == myValue.count
            } else {
                
                return false
            }
        }
    }
    
    // MARK: - 判断字典是否存在
    /// 判断字典是否存在
    ///
    /// - Parameter value: 判断的内容
    /// - Returns: 返回类型
    public static func dictionaryIsEmpty(value: AnyObject?) -> Bool {
        //首先判断是否为nil
        if ( nil == value ) {
            //对象是nil，直接认为是空NSDictionary
            return true;
        } else {
            //然后是否可以转化为NSDictionary
            if let myValue  = value as? NSDictionary{
                //然后对NSDictionary做判断
                return 0 == myValue.count
            } else {

                return false
            }
        }
    }
    
    // MARK: - 获取设备的唯一表示UUID
    /// 获取设备的唯一表示UUID
    public static func getUserDeviceUUIDString() -> String{
        if SwiftTool.isEmptyOrNull(value: UserDefaults.standard.object(forKey: "UUID") as AnyObject?) { UserDefaults.standard.setValue(UIDevice.current.identifierForVendor?.uuidString, forKey: "UUID")
        }
        return UserDefaults.standard.object(forKey: "UUID") as! String
    }
    
    // MARK: - 获取当前时间
    /// 获取当前时间
    ///
    /// - Returns: 时间
    public static func currentTime() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "YYYY-MM-dd HH:mm:ss"// 自定义时间格式
        // GMT时间 转字符串，直接是系统当前时间
        return dateformatter.string(from: Date())
    }
    
    // MARK: - 获取当前系统时间戳
    /// 获取当前系统时间戳
    ///
    /// - Returns: 时间戳
    public static func currentTimeStamp() -> TimeInterval {
        let date = Date()
        // GMT时间转时间戳 没有时差，直接是系统当前时间戳
        return date.timeIntervalSince1970
    }
    
    // MARK: - 获取手机所连接wifi名称
    /// 获取手机所连接wifi名称
    ///
    /// - Returns: 返回手机连接wifi名称
    public static func getUsedSSID() -> String {
        let interfaces = CNCopySupportedInterfaces()
        var ssid = ""
        if interfaces != nil {
            let interfacesArray = CFBridgingRetain(interfaces) as! Array<AnyObject>
            if interfacesArray.count > 0 {
                let interfaceName = interfacesArray[0] as! CFString
                let ussafeInterfaceData = CNCopyCurrentNetworkInfo(interfaceName)
                if (ussafeInterfaceData != nil) {
                    let interfaceData = ussafeInterfaceData as! Dictionary<String, Any>
                    ssid = interfaceData["SSID"]! as! String
                }
            }
        }
        return ssid
    }
    
    // MARK: - 将字符串md5加密
    /// 将字符串md5加密
    ///
    /// - Parameter strs: 要加密的字符串
    /// - Returns: 返回加密后的字符串
    public static func MD5String(strs:String) ->String!{
        let str = strs.cString(using: String.Encoding.utf8)
        let strLen = CUnsignedInt(strs.lengthOfBytes(using: String.Encoding.utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
        CC_MD5(str!, strLen, result)
        let hash = NSMutableString()
        for i in 0 ..< digestLen {
            hash.appendFormat("%02x", result[i])
        }
        result.deallocate()
        return String(format: hash as String)
    }
    
    // MARK: -  判断手机号是否合法
    /// 判断手机号是否合法
    ///
    /// - Parameter num: 手机号
    /// - Returns: 返回是否和法，true 为合法、反之
    public static func isTelNumber(num:NSString)->Bool {
        let mobile = "^1(3[0-9]|5[0-35-9]|8[025-9])\\d{8}$"
        let CM = "^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d)\\d{7}$"
        let CU = "^1(3[0-2]|5[256]|8[56])\\d{8}$"
        let CT = "^1((33|53|8[09])[0-9]|349)\\d{7}$"
        let regextestmobile = NSPredicate(format: "SELF MATCHES %@",mobile)
        let regextestcm = NSPredicate(format: "SELF MATCHES %@",CM )
        let regextestcu = NSPredicate(format: "SELF MATCHES %@",CU)
        let regextestct = NSPredicate(format: "SELF MATCHES %@",CT)
        if ((regextestmobile.evaluate(with: num) == true) || (regextestcm.evaluate(with: num)  == true) || (regextestct.evaluate(with: num) == true) || (regextestcu.evaluate(with: num) == true))  {
            return true
        } else {
            return false
        }
    }
    
    // MARK: - 添加简单的弹框缓冲效果
    /// 添加简单的弹框缓冲效果
    ///
    /// - Parameter allView: 动画View
    public static func animationWithAlertViewWithView(allView:UIView) {
        let animation = CAKeyframeAnimation.init(keyPath: "transform")
        animation.duration = 0.2
        animation.isRemovedOnCompletion = true
        animation.fillMode = CAMediaTimingFillMode.forwards
        let values = NSMutableArray()
        values.add(NSValue.init(caTransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)))
        values.add(NSValue.init(caTransform3D:CATransform3DMakeScale(1.1, 1.1, 1.0)))
        values.add(NSValue.init(caTransform3D:CATransform3DMakeScale(1.0, 1.0, 1.0)))
        animation.values = values as? [Any]
        allView.layer.add(animation, forKey: nil)
    }
    
    // MARK: - 判断是否是异型曲面屏幕
    /// 判断是否是异型曲面屏幕
    public static func isItSpecialCurvedScreen() -> Bool{
        var systemInfo = utsname()
        uname(&systemInfo)
        let platform = withUnsafePointer(to: &systemInfo.machine.0) { ptr in
            return String(cString: ptr)
        }
        if platform == "iPhone10,6" || platform == "iPhone11,8" || platform == "iPhone11,2" || platform == "iPhone11,4" || platform == "iPhone11,6" || platform == "iPhone12,1" || platform == "iPhone12,3" || platform == "iPhone12,5" || platform == "iPhone12,8" || platform == "iPhone13,1" || platform == "iPhone13,2" || platform == "iPhone13,3" || platform == "iPhone13,4" {
            return true
        } else {
            return false
        }
    }
    
    // MARK: - 获取手机型号
    /// 获取手机型号
    func iphoneType() ->String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let platform = withUnsafePointer(to: &systemInfo.machine.0) { ptr in
            return String(cString: ptr)
        }
        if platform == "iPhone1,1" {return"iPhone 2G"}
        if platform == "iPhone1,2" {return"iPhone 3G"}
        if platform == "iPhone2,1" {return"iPhone 3GS"}
        if platform == "iPhone3,1" {return"iPhone 4"}
        if platform == "iPhone3,2" {return"iPhone 4"}
        if platform == "iPhone3,3" {return"iPhone 4"}
        if platform == "iPhone4,1" {return"iPhone 4S"}
        if platform == "iPhone5,1" {return"iPhone 5"}
        if platform == "iPhone5,2" {return"iPhone 5"}
        if platform == "iPhone5,3" {return"iPhone 5C"}
        if platform == "iPhone5,4" {return"iPhone 5C"}
        if platform == "iPhone6,1" {return"iPhone 5S"}
        if platform == "iPhone6,2" {return"iPhone 5S"}
        if platform == "iPhone7,1" {return"iPhone 6 Plus"}
        if platform == "iPhone7,2" {return"iPhone 6"}
        if platform == "iPhone8,1" {return"iPhone 6S"}
        if platform == "iPhone8,2" {return"iPhone 6S Plus"}
        if platform == "iPhone8,4" {return"iPhone SE"}
        if platform == "iPhone9,1" {return"iPhone 7"}
        if platform == "iPhone9,2" {return"iPhone 7 Plus"}
        if platform == "iPhone10,1" {return"iPhone 8"}
        if platform == "iPhone10,2" {return"iPhone 8 Plus"}
        if platform == "iPhone10,3" {return"iPhone X"}
        if platform == "iPhone10,4" {return"iPhone 8"}
        if platform == "iPhone10,5" {return"iPhone 8 Plus"}
        if platform == "iPhone10,6" {return"iPhone X"}
            //新添加
        if platform == "iPhone11,8" {return "iPhone XR"}
        if platform == "iPhone11,2" {return "iPhone XS"}
        if platform == "iPhone11,4" {return "iPhone XS Max"}
        if platform == "iPhone11,6" {return "iPhone XS Max"}
        if platform == "iPhone12,1" {return "iPhone 11"}
        if platform == "iPhone12,3" {return "iPhone 11 Pro"}
        if platform == "iPhone12,5" {return "iPhone 11 Pro Max"}
        if platform == "iPhone12,8" {return "iPhone SE 2020"}
            //结束
        if platform == "iPod1,1" {return"iPod Touch 1G"}
        if platform == "iPod2,1" {return"iPod Touch 2G"}
        if platform == "iPod3,1" {return"iPod Touch 3G"}
        if platform == "iPod4,1" {return"iPod Touch 4G"}
        if platform == "iPod5,1" {return"iPod Touch 5G"}
        if platform == "iPad1,1" {return"iPad 1"}
        if platform == "iPad2,1" {return"iPad 2"}
        if platform == "iPad2,2" {return"iPad 2"}
        if platform == "iPad2,3" {return"iPad 2"}
        if platform == "iPad2,4" {return"iPad 2"}
        if platform == "iPad2,5" {return"iPad Mini 1"}
        if platform == "iPad2,6" {return"iPad Mini 1"}
        if platform == "iPad2,7" {return"iPad Mini 1"}
        if platform == "iPad3,1" {return"iPad 3"}
        if platform == "iPad3,2" {return"iPad 3"}
        if platform == "iPad3,3" {return"iPad 3"}
        if platform == "iPad3,4" {return"iPad 4"}
        if platform == "iPad3,5" {return"iPad 4"}
        if platform == "iPad3,6" {return"iPad 4"}
        if platform == "iPad4,1" {return"iPad Air"}
        if platform == "iPad4,2" {return"iPad Air"}
        if platform == "iPad4,3" {return"iPad Air"}
        if platform == "iPad4,4" {return"iPad Mini 2"}
        if platform == "iPad4,5" {return"iPad Mini 2"}
        if platform == "iPad4,6" {return"iPad Mini 2"}
        if platform == "iPad4,7" {return"iPad Mini 3"}
        if platform == "iPad4,8" {return"iPad Mini 3"}
        if platform == "iPad4,9" {return"iPad Mini 3"}
        if platform == "iPad5,1" {return"iPad Mini 4"}
        if platform == "iPad5,2" {return"iPad Mini 4"}
        if platform == "iPad5,3" {return"iPad Air 2"}
        if platform == "iPad5,4" {return"iPad Air 2"}
        if platform == "iPad6,3" {return"iPad Pro 9.7"}
        if platform == "iPad6,4" {return"iPad Pro 9.7"}
        if platform == "iPad6,7" {return"iPad Pro 12.9"}
        if platform == "iPad6,8" {return"iPad Pro 12.9"}
        if platform == "i386"    {return"iPhone Simulator"}
        if platform == "x86_64"  {return"iPhone Simulator"}
        return platform
    }
    
    public static func setsTheViewBorderAndRounded(view: UIView,color: UIColor? = nil,width: CGFloat? = nil,radius: CGFloat? = nil ) {
        view.layer.borderWidth = width ?? 0
        view.layer.borderColor = color?.cgColor
        guard let radius = radius else {
            return
        }
        view.clipsToBounds = true
        view.layer.cornerRadius = radius
    }

}
